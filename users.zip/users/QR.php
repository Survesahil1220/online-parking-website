<?php
include('includes/dbconnection.php');

// Check if Parking ID is passed via URL
if (isset($_GET['parkingID'])) {
    $parkingID = $_GET['parkingID']; // Get the parking number from the URL
    
    // Fetch details from the database based on Parking ID
    $query = mysqli_query($con, "SELECT v.RegistrationNumber, v.VehicleCompanyname, v.ParkingAt, u.FirstName, u.LastName,v.ownername  , v.floor
                                FROM tblvehicle v 
                                JOIN tblregusers u ON v.OwnerContactNumber = u.MobileNumber 
                                WHERE v.ID = '$parkingID'");
    $result = mysqli_fetch_array($query);
    
    if ($result) {
        $firstName = $result['FirstName'];
        $lastName = $result['LastName'];
        $ownername = $result['ownername'];
        $registrationNumber = $result['RegistrationNumber'];
        $vehicleCompany = $result['VehicleCompanyname'];
        $parkingAt = $result['ParkingAt'];
        $floor = $result['floor'];
    } else {
        echo "No details found for the provided Parking ID!";
        exit;
    }
} else {
    echo "No Parking ID provided!";
    exit;
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code for Parking</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            flex-direction: column;
            background-color: #f4f4f9;
        }
        .container {
            width: 80%;
            max-width: 600px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
        }
        h1 {
            color: #333;
            font-size: 24px;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            margin: 8px 0;
            color: #555;
        }
        .qr-code {
            margin-top: 20px;
        }
        .qr-code img {
            width: 200px;
            height: 200px;
        }
        .details {
            margin-top: 30px;
            font-size: 16px;
        }
        .details strong {
            color: #333;
        }
        .details p {
            margin: 5px 0;
        }
        .back-button {
            margin-top: 30px;
            padding: 10px 20px;
            font-size: 16px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .back-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>QR Code for Parking ID: <?php echo htmlspecialchars($parkingID); ?></h1>
        
        <!-- Display Parking details -->
        <div class="details">
            <p><strong>Owner Name:</strong> <?php echo htmlspecialchars($ownername); ?></p>
            <p><strong>Registration Number:</strong> <?php echo htmlspecialchars($registrationNumber); ?></p>
            <p><strong>Vehicle Company:</strong> <?php echo htmlspecialchars($vehicleCompany); ?></p>
            <p><strong>Parking At:</strong> <?php echo htmlspecialchars($parkingAt); ?></p>
            <p><strong>praking Number:</strong> <?php echo htmlspecialchars($parkingID); ?></p>
            <p><strong>Floor:</strong> <?php echo htmlspecialchars($floor); ?></p>
        </div>

        <!-- Generate the QR code with Parking ID, Registration Number, and Owner Name -->
        <div class="qr-code">
            <img src="https://qrickit.com/api/qr.php?d=Parking%20ID:%20<?php echo urlencode($parkingID); ?>%20|%20Reg%20No:%20<?php echo urlencode($registrationNumber); ?>%20|%20Owner:%20<?php echo urlencode($ownername); ?>&addtext=Parking%20ID%20<?php echo urlencode($parkingID); ?>&addtext=floor%20%20<?php echo urlencode($floor); ?>" alt="QR Code" />
        </div>

        <!-- Optional details -->
        <p>More details about the parking spot can go here.</p>

        <!-- Back Button to View Vehicle -->
        <a href="view-vehicle.php" class="back-button">Back to Vehicle List</a>
    </div>

</body>
</html>