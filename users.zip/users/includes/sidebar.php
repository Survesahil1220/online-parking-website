<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">
        
        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="nav-item active">
                    <a href="dashboard.php" class="nav-link">
                        <i class="menu-icon fa fa-laptop"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="view-vehicle.php" class="nav-link">
                        <i class="menu-icon fa fa-truck"></i>
                        <span>View Vehicle</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="Search-location.php" class="nav-link">
                        <i class="menu-icon fa fa-search"></i>
                        <span>Search Location</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
</aside>