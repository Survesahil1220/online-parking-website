<div id="right-panel" class="right-panel">
    <header id="header" class="header">
        <div class="top-left">
            <div class="navbar-header">
                SpaceFinder
            </div>
        </div>
        <div class="top-right">
            <div class="header-menu d-flex align-items-center">
                <?php
                session_start();
                $user_id = $_SESSION['vpmsuid'] ?? 1;
                $query = mysqli_query($con, "SELECT balance FROM tblregusers WHERE ID = '$user_id'");
                $wallet = mysqli_fetch_array($query);
                $balance = $wallet['balance'] ?? 0.00;
                ?>
                <div class="balance-container ml-3">
                    <span class="badge badge-pill balance-badge">
                        Balance: ₹<?php echo number_format($balance, 2); ?>
                    </span>
                </div>
                <div class="user-area dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <img class="user-avatar rounded-circle" src="../admin/images/images.png" alt="User Avatar">
                    </a>
                    <div class="user-menu dropdown-menu">
                        <a class="nav-link" href="profile.php"><i class="fa fa-user"></i> My Profile</a>
                        <a class="nav-link" href="change-password.php"><i class="fa fa-cog"></i> Change Password</a>
                        <a class="nav-link" href="wallet.php"><i class="fa fa-money"></i> Wallet</a>
                        <a class="nav-link" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </header>
</div>

<style>
    :root {
        --primary-color: #2c3e50;
        --secondary-color: #3498db;
        --accent-color: #e74c3c;
        --text-color: #333;
        --bg-color: #f5f6fa;
    }

    .header {
        background: #fff;
        padding: 15px 30px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .navbar-header {
        font-size: 24px;
        font-weight: 700;
        color: var(--primary-color);
    }

    .balance-container {
        margin-right: 20px;
    }

    .balance-badge {
        background: #fff;
        color: #27ae60;
        font-size: 16px;
        padding: 8px 15px;
        border: 2px solid #27ae60;
        font-weight: 600;
        border-radius: 20px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    }

    .user-avatar {
        width: 40px;
        height: 40px;
        border: 2px solid var(--secondary-color);
        padding: 2px;
        transition: transform 0.3s ease;
    }

    .user-avatar:hover {
        transform: scale(1.1);
    }

    .dropdown-menu {
        background: #fff;
        border: none;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border-radius: 8px;
        min-width: 180px;
        margin-top: 10px;
        left: auto;
        right: 0;
    }

    .dropdown-menu .nav-link {
        color: var(--text-color);
        padding: 10px 20px;
        transition: all 0.3s ease;
    }

    .dropdown-menu .nav-link:hover {
        background: var(--secondary-color);
        color: #fff;
        padding-left: 25px;
    }

    .dropdown-menu .fa {
        margin-right: 10px;
        width: 20px;
    }
    .user-menu {
        left: -100px; /* Adjust this value as needed */
        margin-top: 30px; /* Add gap from above */
    }
    /* Dropdown text color */
.dropdown-menu a {
    color: black !important;
}
</style>