<?php
include('includes/dbconnection.php');

if (isset($_POST['location'])) {
    $location = $_POST['location'];
    $query = mysqli_query($con, "SELECT ParkingName, Latitude, Longitude FROM tbllocation WHERE LocationName = '$location' ORDER BY ParkingName ASC");

    echo '<option value="">Select Parking</option>';
    while ($row = mysqli_fetch_array($query)) {
        echo '<option value="' . $row['ParkingName'] . '" 
                data-lat="' . $row['Latitude'] . '" 
                data-lng="' . $row['Longitude'] . '">
                ' . $row['ParkingName'] . '
              </option>';
    }
}
?>
