<?php
session_start();

// Check if OTP exists in the session
if (!isset($_SESSION['otp'])) {
    echo "No OTP found. Please request an OTP first.";
    exit();
}

// Process OTP verification
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the user submitted the OTP
    if (isset($_POST['otp'])) {
        $userOtp = $_POST['otp'];

        // Verify OTP
        if ($userOtp == $_SESSION['otp']) {
            // Redirect to dashboard.php if OTP is correct
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid OTP. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #333;
        }

        .container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        h2 {
            margin-bottom: 40px;
            color: #333;
        }

        input[type="text"] {
            border: 1px solid #e0e0e0;
            border-radius: 4px;
            padding: 12px;
            margin-bottom: 20px;
            font-size: 16px;
            width: calc(100% - 24px); /* Adjust for padding */
        }

        input[type="text"]:focus {
            outline: none;
            border-color: #007bff;
        }

        button {
            background-color: #007bff;
            border: none;
            color: white;
            padding: 12px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            width: 100%;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b2;
        }

        .error {
            color: red;
            margin-top: 10px;
            font-size: 14px;
        }

        @media (max-width: 480px) {
            .container {
                padding: 20px;
            }

            input[type="text"] {
                font-size: 14px;
            }

            button {
                font-size: 14px;
            }
        }
    </style><script>
        document.addEventListener('DOMContentLoaded', function() {
            var otpInput = document.querySelector('input[name="otp"]');
            otpInput.addEventListener('input', function() {
                this.value = this.value.replace(/\D/g, '');
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <h2>Verify OTP</h2>
        <form method="post" action="">
        <input type="text" name="otp" placeholder="Enter your OTP" maxlength="6" pattern="\d{6}" required>
            <button type="submit">Verify OTP</button>
        </form>
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
    </div>
</body>
</html>
