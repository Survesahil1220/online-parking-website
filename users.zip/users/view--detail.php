<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['vpmsuid']) == 0) {
    header('location:logout.php');
} else {
    // Handle Delete Action
    if (isset($_GET['deleteid'])) {
        $deleteId = $_GET['deleteid'];
        $deleteQuery = mysqli_query($con, "DELETE FROM tblvehicle WHERE ID='$deleteId'");
        if ($deleteQuery) {
            echo '<script>alert("Vehicle entry has been deleted.")</script>';
            echo '<script>window.location.href="view-vehicle.php"</script>';
        } else {
            echo '<script>alert("Failed to delete vehicle entry. Please try again.")</script>';
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SpaceFinder - View Vehicle Detail</title>

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">

    <!-- Custom Styles -->
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --text-color: #333;
            --bg-color: #f5f6fa;
            --sidebar-gradient-start: #2c3e50;
            --sidebar-gradient-end: #34495e;
            --border-color: #d1dce5;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }

        .left-panel {
            background: linear-gradient(135deg, var(--sidebar-gradient-start), var(--sidebar-gradient-end));
            height: 100vh;
            position: fixed;
            width: 250px;
            box-shadow: 3px 0 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            overflow-y: auto;
            top: 0;
            left: 0;
        }

        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }

        .sidebar-title {
            color: #fff;
            font-size: 24px;
            font-weight: 700;
            margin: 0;
            letter-spacing: 1px;
        }

        .navbar-nav {
            padding: 20px 0;
        }

        .nav-item {
            margin: 5px 0;
            position: relative;
        }

        .nav-link {
            color: #fff !important;
            padding: 15px 25px !important;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            border-radius: 0 25px 25px 0;
            font-weight: 500;
        }

        .nav-link:hover, .nav-link.active {
            background: var(--secondary-color);
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .nav-item.active .nav-link {
            background: var(--secondary-color);
        }

        .menu-icon {
            margin-right: 15px;
            font-size: 20px;
            width: 25px;
            text-align: center;
        }

        .right-panel {
            margin-left: 250px;
            padding-top: 70px;
        }

        .header {
            position: fixed;
            top: 0;
            left: 250px;
            right: 0;
            z-index: 1000;
            background: #fff;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .breadcrumbs {
            background: #fff;
            padding: 15px 30px;
            border-bottom: 1px solid var(--border-color);
            margin: 20px 0;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .breadcrumb {
            background: none;
            padding: 0;
            margin: 0;
        }

        .breadcrumb-item a {
            color: var(--secondary-color);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .breadcrumb-item a:hover {
            color: var(--primary-color);
        }

        .breadcrumb-item.active {
            color: var(--text-color);
            font-weight: 500;
        }

        .content {
            padding: 0 30px 30px;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        .card-header {
            background: var(--primary-color);
            color: #fff;
            padding: 15px 20px;
            font-size: 18px;
            font-weight: 600;
            border-bottom: none;
        }

        .card-body {
            padding: 20px;
        }

        .table {
            margin-bottom: 0;
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            background: #fff;
            border-radius: 5px;
            overflow: hidden;
        }

        .table th {
            background: #f8f9fa;
            color: var(--primary-color);
            font-weight: 600;
            padding: 15px 20px;
            border-bottom: 2px solid var(--border-color);
            text-align: left;
            font-size: 14px;
            letter-spacing: 0.5px;
            width: 30%;
        }

        .table td {
            padding: 15px 20px;
            vertical-align: middle;
            border-top: 1px solid var(--border-color);
            font-size: 15px;
        }

        .table tr:hover {
            background: #f8f9fa;
        }

        .btn-delete {
            background: var(--accent-color);
            color: #fff;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            font-weight: 500;
            transition: background 0.3s ease;
            text-decoration: none;
        }

        .btn-delete:hover {
            background: #c0392b;
            color: #fff;
        }

        @media (max-width: 768px) {
            .left-panel {
                width: 70px;
            }

            .right-panel {
                margin-left: 70px;
            }

            .header {
                left: 70px;
            }

            .content {
                padding: 0 15px 15px;
            }

            .breadcrumbs {
                padding: 10px 15px;
                margin: 10px 0;
            }

            .table {
                border: none;
            }

            .table tr {
                display: block;
                margin-bottom: 15px;
                border: 1px solid var(--border-color);
                border-radius: 5px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            }

            .table th, .table td {
                display: block;
                width: 100%;
                border: none;
                padding: 10px 15px;
            }

            .table th {
                background: #e9ecef;
                border-bottom: 1px solid var(--border-color);
            }
        }
    </style>
</head>
<body>
    <?php include_once('includes/sidebar.php'); ?>
    <?php include_once('includes/header.php'); ?>

    <div class="right-panel">
        <div class="breadcrumbs">
            <div class="container-fluid">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="view-vehicle.php">View Vehicle</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Vehicle Details</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="content">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Vehicle Details</strong>
                            </div>
                            <div class="card-body">
                                <?php
                                $cid = $_GET['viewid'];
                                $ret = mysqli_query($con, "SELECT * FROM tblvehicle WHERE ID='$cid'");
                                $cnt = 1;
                                while ($row = mysqli_fetch_array($ret)) {
                                ?>
                                <table class="table">
                                    <tr>
                                        <th>Parking At</th>
                                        <td><?php echo $row['ParkingAt']; ?></td> <!-- Added Parking At -->
                                    </tr>
                                    
                                    <tr>
                                        <th>floor</th>
                                        <td><?php echo $row['Floor']; ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <th>Parking Number</th>
                                        <td><?php echo $row['ParkingNumber']; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Vehicle Category</th>
                                        <td><?php echo $row['VehicleCategory']; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Vehicle Company Name</th>
                                        <td><?php echo $row['VehicleCompanyname']; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Registration Number</th>
                                        <td><?php echo $row['RegistrationNumber']; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Owner Name</th>
                                        <td><?php echo $row['OwnerName']; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Owner Contact Number</th>
                                        <td><?php echo $row['OwnerContactNumber']; ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <th>In Time</th>
                                        <td><?php echo $row['InTime']; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Status</th>
                                        <td>
                                            <?php  
                                            if ($row['Status'] == "IN") {
                                                echo "Vehicle In";
                                            } elseif ($row['Status'] == "Out") {
                                                echo "Vehicle Out";
                                            }
                                            ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Remark</th>
                                        <td><?php echo $row['Remark']; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Parking Fee</th>
                                        <td><?php echo $row['ParkingCharge']; ?></td>
                                    </tr>
                                </table>
                                <div class="text-center mt-3 d-flex justify-content-center">
                                    <a href="?deleteid=<?php echo $row['ID']; ?>" class="btn-delete mr-2" onclick="return confirm('Are you sure you want to delete this vehicle entry?');">Delete</a>
                                    <a href="view-vehicle.php" class="btn btn-secondary">Back to View Vehicle</a>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php } ?>