<?php
session_start();
include('includes/dbconnection.php');

// Function to generate OTP
function generateOTP() {
    $length = 6;
    $characters = '0123456789';
    $otp = '';
    for ($i = 0; $i < $length; $i++) {
        $otp .= $characters[mt_rand(0, strlen($characters) - 1)];
    }
    return $otp;
}

// Check if OTP verification is requested
if (isset($_GET['verify'])) {
    if (isset($_POST['otp'])) {
        // Verify OTP
        if ($_POST['otp'] == $_SESSION['otp']) {
            // Redirect to dashboard.php
            header("Location: dashboard.php");
            exit();
        } else {
            echo "Invalid OTP.";
        }
    }
} elseif (isset($_POST['send_otp'])) {
    // Generate OTP
    $otp = generateOTP();

    // Store OTP in session
    $_SESSION['otp'] = $otp;

    // Prepare email content
    $to = $_SESSION['vpmsemail']; // Use email from session
    $subject = "Your OTP for VPMS Verification";
    $message = '
    <html>
    <head>
        <title>Your OTP for VPMS</title>
        <style>
            body { font-family: Arial, sans-serif; color: #333; line-height: 1.6; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #007bff; color: white; padding: 15px; text-align: center; border-radius: 5px 5px 0 0; }
            .content { padding: 20px; background-color: #f8f9fa; border: 1px solid #e0e0e0; border-radius: 0 0 5px 5px; }
            .otp { font-size: 24px; font-weight: bold; color: #007bff; text-align: center; margin: 20px 0; }
            .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #777; }
            a { color: #007bff; text-decoration: none; }
            a:hover { text-decoration: underline; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h2>Space Finder - OTP Verification</h2>
            </div>
            <div class="content">
                <p>Dear User,</p>
                <p>Thank you for using the Vehicle Parking Management System (VPMS). To verify your email address, please use the following One-Time Password (OTP):</p>
                <div class="otp">' . htmlspecialchars($otp) . '</div>
                <p>This OTP is valid for a single use and will expire shortly. Please enter it on the verification page to proceed.</p>
                <p>If you didn\'t request to verify this email address, you can safely ignore this email.</p>
                <p>Best regards,<br>The Space Finder Team</p>
            </div>
            <div class="footer">
                <p>&copy; ' . date('Y') . ' Space Finder. All rights reserved. | <a href="https://spacefinder.example.com">Visit our website</a></p>
            </div>
        </div>
    </body>
    </html>';
    $headers = "From: Space Finder <your-email@example.com>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    // Send email
    if (mail($to, $subject, $message, $headers)) {
        // Redirect to verifyotp.php after sending OTP
        header("Location: verifyotp.php?sent=1");
        exit();
    } else {
        echo "Failed to send email.";
    }
} else {
    // Display form to trigger OTP sending
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>VPMS Login</title>
        <style>
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f8f9fa;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        color: #333;
    }

    .container {
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
        padding: 30px;
        width: 100%;
        max-width: 400px;
        position: relative;
    }

    h2 {
        text-align: center;
        margin-bottom: 40px;
        color: #333;
    }

    form {
        display: flex;
        flex-direction: column;
    }

    .email-container {
        position: relative;
        margin-bottom: 20px;
    }

    input[type="email"] {
        border: 1px solid #e0e0e0;
        border-radius: 4px;
        padding: 12px;
        font-size: 16px;
        width: 100%;
        box-sizing: border-box;
    }

    input[type="email"]:focus {
        outline: none;
        border-color: #007bff;
    }

    .email-container::after {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(128, 128, 128, 0.4);
        border-radius: 4px;
        pointer-events: none;
    }

    button {
        background-color: #007bff;
        border: none;
        color: white;
        padding: 12px;
        font-size: 16px;
        cursor: pointer;
        border-radius: 4px;
        transition: background-color 0.3s ease;
    }

    button:hover {
        background-color: #0056b2;
    }

    /* Loading animation styles */
    .loading-overlay {
        display: none;
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255, 255, 255, 0.8);
        border-radius: 10px;
        justify-content: center;
        align-items: center;
    }

    .spinner {
        width: 40px;
        height: 40px;
        border: 4px solid #007bff;
        border-top: 4px solid transparent;
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    @media (max-width: 480px) {
        .container {
            padding: 20px;
        }

        input[type="email"] {
            font-size: 14px;
        }

        button {
            font-size: 14px;
        }
    }
</style>
    </head>
    <body>
        <div class="container">
            <?php if (!isset($_GET['verify'])): ?>
                <h2>OTP will be sent to your email:</h2>
                <form action="" method="post" id="otpForm">
                    <div class="email-container">
                        <input type="email" name="email" required placeholder="Your email" value="<?php echo htmlspecialchars($_SESSION['vpmsemail']); ?>" readonly>
                    </div>
                    <input type="hidden" name="send_otp" value="1">
                    <button type="submit" id="sendOtpBtn">Send OTP</button>
                    <div class="flex justify-center space-x-4">
                        <button type="button" onclick="window.location.href='dashboard.php'" style="opacity: 0.5; display: block; margin: 0 auto;" class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 cursor-pointer">
                            test
                        </button>
                    </div>
                    <!-- Loading overlay -->
                    <div class="loading-overlay" id="loadingOverlay">
                        <div class="spinner"></div>
                    </div>
                </form>
            <?php endif; ?>
        </div>
        <script>
            document.getElementById('otpForm').addEventListener('submit', function(event) {
                // Prevent immediate form submission
                event.preventDefault();
                
                // Show loading animation
                document.getElementById('loadingOverlay').style.display = 'flex';
                // Disable the button to prevent multiple submissions
                document.getElementById('sendOtpBtn').disabled = true;

                // Wait 8 seconds before submitting the form
                setTimeout(function() {
                    // Submit the form programmatically
                    document.getElementById('otpForm').submit();
                }, 8000);
            });
        </script>
    </body>
    </html>
    <?php
}
?>