<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['vpmsuid']) == 0) {
    header('location:logout.php');
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SpaceFinder - View Vehicle Parking Details</title>

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">

    <!-- Custom Styles -->
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --text-color: #333;
            --bg-color: #f5f6fa;
            --sidebar-gradient-start: #2c3e50;
            --sidebar-gradient-end: #34495e;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }

        /* Sidebar Styles (unchanged, for consistency) */
        .left-panel {
            background: linear-gradient(135deg, var(--sidebar-gradient-start), var(--sidebar-gradient-end));
            height: 100vh;
            position: fixed;
            width: 250px;
            box-shadow: 3px 0 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            overflow-y: auto;
            top: 0;
            left: 0;
        }

        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }

        .sidebar-title {
            color: #fff;
            font-size: 24px;
            font-weight: 700;
            margin: 0;
            letter-spacing: 1px;
        }

        .navbar-nav {
            padding: 20px 0;
        }

        .nav-item {
            margin: 5px 0;
            position: relative;
        }

        .nav-link {
            color: #fff !important;
            padding: 15px 25px !important;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            border-radius: 0 25px 25px 0;
            font-weight: 500;
        }

        .nav-link:hover, .nav-link.active {
            background: var(--secondary-color);
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .nav-item.active .nav-link {
            background: var(--secondary-color);
        }

        .menu-icon {
            margin-right: 15px;
            font-size: 20px;
            width: 25px;
            text-align: center;
        }

        /* Content Styles */
        .right-panel {
            margin-left: 250px;
            padding-top: 70px; /* Adjust for header height */
        }

        .header {
            position: fixed;
            top: 0;
            left: 250px;
            right: 0;
            z-index: 1000;
            background: #fff;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .breadcrumbs {
            background: #fff;
            padding: 15px 30px;
            border-bottom: 1px solid #e9ecef;
            margin: 20px 0;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .breadcrumb {
            background: none;
            padding: 0;
            margin: 0;
        }

        .breadcrumb-item a {
            color: var(--secondary-color);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .breadcrumb-item a:hover {
            color: var(--primary-color);
        }

        .breadcrumb-item.active {
            color: var(--text-color);
            font-weight: 500;
        }

        .content {
            padding: 0 30px 30px;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        .card-header {
            background: var(--primary-color);
            color: #fff;
            padding: 15px 20px;
            font-size: 18px;
            font-weight: 600;
            border-bottom: none;
        }

        .card-body {
            padding: 20px;
        }

        .table {
            margin-bottom: 0;
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            background: #fff;
            border-radius: 5px;
            overflow: hidden;
        }

        .table thead th {
            background: #f8f9fa;
            color: var(--primary-color);
            font-weight: 600;
            padding: 15px 20px;
            border-bottom: 2px solid #e9ecef;
            text-transform: uppercase;
            font-size: 14px;
            letter-spacing: 0.5px;
        }

        .table tbody tr {
            transition: all 0.3s ease;
        }

        .table tbody tr:hover {
            background: #f8f9fa;
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .table td {
            padding: 15px 20px;
            vertical-align: middle;
            border-top: 1px solid #e9ecef;
        }

        .btn {
            padding: 8px 15px;
            border-radius: 5px;
            font-weight: 500;
            transition: all 0.3s ease;
            margin: 0 5px;
        }

        .btn-primary {
            background: var(--secondary-color);
            border: none;
        }

        .btn-primary:hover {
            background: #2980b9;
        }

        .btn-warning {
            background: #f1c40f;
            border: none;
            color: #fff;
        }

        .btn-warning:hover {
            background: #d4ac0d;
        }

        .btn-danger {
            background: var(--accent-color);
            border: none;
        }

        .btn-danger:hover {
            background: #c0392b;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .left-panel {
                width: 70px;
            }

            .right-panel {
                margin-left: 70px;
            }

            .header {
                left: 70px;
            }

            .content {
                padding: 0 15px 15px;
            }

            .breadcrumbs {
                padding: 10px 15px;
                margin: 10px 0;
            }

            .table-responsive {
                border: none;
            }

            .table thead {
                display: none;
            }

            .table tbody tr {
                display: block;
                margin-bottom: 15px;
                border: 1px solid #e9ecef;
                border-radius: 5px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            }

            .table td {
                display: flex;
                justify-content: space-between;
                border: none;
                padding: 10px 15px;
                text-align: right;
            }

            .table td:before {
                content: attr(data-label);
                font-weight: 600;
                color: var(--primary-color);
                flex: 1;
                text-align: left;
            }

            .table td:last-child {
                justify-content: center;
                flex-wrap: wrap;
            }

            .btn {
                margin: 5px;
            }
        }
    </style>
</head>
<body>
    <?php include_once('includes/sidebar.php'); ?>
    <?php include_once('includes/header.php'); ?>

    <div class="right-panel">
        <div class="breadcrumbs">
            <div class="container-fluid">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="view-vehicle.php">View Vehicle</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Parking Details</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="content">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Your Parked Vehicles</strong>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Parking Number</th>
                                                <!-- <th>Owner Name</th> -->
                                                <th>Vehicle Reg Number</th>
                                                <th>Selected Location</th>
                                                <th>Parking At</th> <!-- Added Parking At column -->
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $ownerno = $_SESSION['vpmsumn'];
                                            $ret = mysqli_query($con, "SELECT tblregusers.FirstName, tblregusers.LastName, tblregusers.MobileNumber, tblregusers.Email,
                                                tblvehicle.ParkingNumber, tblvehicle.VehicleCategory, tblvehicle.VehicleCompanyname,tblvehicle.ID,
                                                tblvehicle.RegistrationNumber, tblvehicle.OwnerName, tblvehicle.ID as vehid,
                                                tblvehicle.OwnerContactNumber, tblvehicle.InTime, tblvehicle.OutTime, tblvehicle.ParkingAt, tblvehicle.Location
                                                FROM tblvehicle
                                                JOIN tblregusers ON tblregusers.MobileNumber = tblvehicle.OwnerContactNumber
                                                WHERE tblvehicle.OwnerContactNumber = '$ownerno'");
                                            $ret2 =mysqli_query($con, "SELECT * FROM tblvehicle WHERE RegistrationNumber = '$ownerno'");

                                            $cnt = 1;
                                            while ($row = mysqli_fetch_array($ret)) {
                                            ?>
                                            <tr>
                                                <td data-label="S.No"><?php echo $cnt; ?></td>
                                                <td data-label="Parking Number"><?php echo $row['ParkingNumber']; ?></td>
                                            <!--    <td data-label="Owner Name"><?php// echo $row2['OwnerName']; ?></td> -->
                                                <td data-label="Vehicle Reg Number"><?php echo $row['RegistrationNumber']; ?></td>
                                                <td data-label="Selected Location"><?php echo $row['Location']; ?></td>
                                                <td data-label="Parking At"><?php echo $row['ParkingAt']; ?></td> <!-- Added Parking At data -->
                                                <td data-label="Action" style="white-space: nowrap;">
                                                    <a href="view--detail.php?viewid=<?php echo $row['vehid']; ?>" class="btn btn-primary btn-sm">View</a>
                                                    <a href="print.php?vid=<?php echo $row['vehid']; ?>" target="_blank" class="btn btn-warning btn-sm">Print</a>
                                                    <a href="QR.php?parkingID=<?php echo urlencode($row['ID']); ?>" class="btn btn-danger btn-sm">QR</a>
                                                </td>
                                            </tr>
                                            <?php 
                                            $cnt++;
                                            } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php } ?>