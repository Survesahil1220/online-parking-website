<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['vpmsuid']) == 0) {
    header('location:logout.php');
} else {
    $location = isset($_GET['location']) ? $_GET['location'] : '';
    $parkingAt = isset($_GET['parkingAt']) ? $_GET['parkingAt'] : '';
    $adminId = isset($_GET['adminId']) ? $_GET['adminId'] : '';

    // Fetch location data including floor slots
    $query = mysqli_query($con, "SELECT ParkingSlotsAvailable, Floor0Slots, Floor1Slots, Floor2Slots, Floor3Slots, Floor4Slots 
                                FROM tbllocation 
                                WHERE LocationName='$location' AND ParkingAt='$parkingAt'");
    $locationData = mysqli_fetch_array($query);
    $totalSlots = $locationData ? $locationData['ParkingSlotsAvailable'] : 0;
    $floorSlots = [
        0 => $locationData ? $locationData['Floor0Slots'] : 0,
        1 => $locationData ? $locationData['Floor1Slots'] : 0,
        2 => $locationData ? $locationData['Floor2Slots'] : 0,
        3 => $locationData ? $locationData['Floor3Slots'] : 0,
        4 => $locationData ? $locationData['Floor4Slots'] : 0
    ];

    // Default floor
    $selectedFloor = isset($_POST['floor']) ? $_POST['floor'] : 0;

    // Fetch occupied parking numbers for the default floor
    $occupiedQuery = mysqli_query($con, "SELECT ParkingNumber 
                                        FROM tblvehicle 
                                        WHERE Location='$location' AND ParkingAt='$parkingAt' AND Floor='$selectedFloor' AND Status='IN'");
    $occupied_numbers = [];
    while ($row = mysqli_fetch_array($occupiedQuery)) {
        $occupied_numbers[] = $row['ParkingNumber'];
    }

    // Generate parking numbers for the default floor
    $all_numbers = $floorSlots[$selectedFloor] > 0 ? range(1, $floorSlots[$selectedFloor]) : [];

    $userMobile = '';
    if (isset($_SESSION['vpmsumn'])) {
        $userMobile = $_SESSION['vpmsumn'];
    } elseif (isset($_GET['userMobile'])) {
        $userMobile = $_GET['userMobile'];
    } else {
        $userQuery = mysqli_query($con, "SELECT MobileNumber FROM tblregusers LIMIT 1");
        $userData = mysqli_fetch_array($userQuery);
        $userMobile = $userData ? $userData['MobileNumber'] : '';
    }

    if (isset($_POST['submit'])) {
        $parkingnumber = $_POST['selectedParkingNumber'];
        $catename = $_POST['catename'];
        $vehcomp = $_POST['vehcomp'];
        $vehreno = $_POST['vehreno'];
        $ownername = $_POST['ownername'];
        $ownercontno = $userMobile;
        $location = $_GET['location'];
        $parkingAt = $_GET['parkingAt'];
        $floor = $_POST['floor'];
        $status = 'IN';
        $query = mysqli_query($con, "INSERT INTO tblvehicle(
            ParkingNumber,
            VehicleCategory,
            VehicleCompanyname,
            RegistrationNumber,
            OwnerName,
            OwnerContactNumber,
            Location,
            ParkingAt,
            Floor,
            Status,
            AdminID
        ) VALUES (
            '$parkingnumber',
            '$catename',
            '$vehcomp',
            '$vehreno',
            '$ownername',
            '$ownercontno',
            '$location',
            '$parkingAt',
            '$floor',
            '$status',
            '$adminId'
        )");
        
        if ($query) {
            echo "<script>alert('Vehicle Entry Detail has been added');</script>";
            echo "<script>window.location.href ='view-vehicle.php'</script>";
        } else {
            echo "<script>alert('Something Went Wrong. Please try again.');</script>";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SpaceFinder - Add Vehicle</title>

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">

    <!-- Custom Styles -->
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --text-color: #333;
            --bg-color: #f5f6fa;
            --sidebar-gradient-start: #2c3e50;
            --sidebar-gradient-end: #34495e;
            --border-color: #d1dce5;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }

        .left-panel {
            background: linear-gradient(135deg, var(--sidebar-gradient-start), var(--sidebar-gradient-end));
            height: 100vh;
            position: fixed;
            width: 250px;
            box-shadow: 3px 0 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            overflow-y: auto;
            top: 0;
            left: 0;
        }

        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }

        .sidebar-title {
            color: #fff;
            font-size: 24px;
            font-weight: 700;
            margin: 0;
            letter-spacing: 1px;
        }

        .navbar-nav {
            padding: 20px 0;
        }

        .nav-item {
            margin: 5px 0;
            position: relative;
        }

        .nav-link {
            color: #fff !important;
            padding: 15px 25px !important;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            border-radius: 0 25px 25px 0;
            font-weight: 500;
        }

        .nav-link:hover, .nav-link.active {
            background: var(--secondary-color);
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .nav-item.active .nav-link {
            background: var(--secondary-color);
        }

        .menu-icon {
            margin-right: 15px;
            font-size: 20px;
            width: 25px;
            text-align: center;
        }

        .right-panel {
            margin-left: 250px;
            padding-top: 70px;
        }

        .header {
            position: fixed;
            top: 0;
            left: 250px;
            right: 0;
            z-index: 1000;
            background: #fff;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .breadcrumbs {
            background: #fff;
            padding: 15px 30px;
            border-bottom: 1px solid var(--border-color);
            margin: 20px 0;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .breadcrumb {
            background: none;
            padding: 0;
            margin: 0;
        }

        .breadcrumb-item a {
            color: var(--secondary-color);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .breadcrumb-item a:hover {
            color: var(--primary-color);
        }

        .breadcrumb-item.active {
            color: var(--text-color);
            font-weight: 500;
        }

        .content {
            padding: 0 30px 30px;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        .card-header {
            background: var(--primary-color);
            color: #fff;
            padding: 15px 20px;
            font-size: 18px;
            font-weight: 600;
            border-bottom: none;
        }

        .card-body {
            padding: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-control-label {
            font-weight: 600;
            color: var(--primary-color);
        }

        .form-control {
            border: 1px solid var(--border-color);
            border-radius: 5px;
            padding: 10px;
            transition: border-color 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 8px rgba(52, 152, 219, 0.5);
        }

        .form-control[readonly] {
            background: #f8f9fa;
            color: #666;
        }

        #parking-spaces {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .parking-spot {
            width: 60px;
            height: 60px;
            color: #fff;
            text-align: center;
            line-height: 60px;
            font-size: 18px;
            font-weight: 600;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .parking-spot.available {
            background: linear-gradient(45deg, #00b894, #00d573);
            cursor: pointer;
            box-shadow: 0 5px 15px rgba(0, 184, 148, 0.4);
        }

        .parking-spot.occupied {
            background: linear-gradient(45deg, #ff4757, #ff6b81);
            cursor: not-allowed;
            opacity: 0.7;
        }

        .parking-spot.selected {
            border: 3px solid #27ae60;
            transform: scale(1.05);
        }

        .parking-spot.available:hover {
            transform: scale(1.05) rotate(2deg);
            box-shadow: 0 8px 20px rgba(0, 184, 148, 0.6);
        }

        .btn-primary {
            background: var(--secondary-color);
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: 500;
            transition: background 0.3s ease;
        }

        .btn-primary:hover {
            background: #2980b9;
        }

        .btn-primary:disabled {
            background: #95a5a6;
            cursor: not-allowed;
        }

        @media (max-width: 768px) {
            .left-panel {
                width: 70px;
            }

            .right-panel {
                margin-left: 70px;
            }

            .header {
                left: 70px;
            }

            .content {
                padding: 0 15px 15px;
            }

            .breadcrumbs {
                padding: 10px 15px;
                margin: 10px 0;
            }

            .form-group {
                margin-bottom: 15px;
            }

            .col-md-3 {
                margin-bottom: 10px;
            }

            #parking-spaces {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <?php include_once('includes/sidebar.php'); ?>
    <?php include_once('includes/header.php'); ?>

    <div class="right-panel">
        <div class="breadcrumbs">
            <div class="container-fluid">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="add-vehicle.php">Vehicle</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Add Vehicle</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="content">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <strong>Add Vehicle</strong>
                                <?php if ($location && $parkingAt) {
                                    echo "<br><small>Location: " . htmlspecialchars($location) . " - " . htmlspecialchars($parkingAt) . "</small>";
                                } ?>
                            </div>
                            <div class="card-body">
                                <form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
                                    <div class="row form-group">
                                        <div class="col col-md-3"><label for="floor" class="form-control-label">Select Floor</label></div>
                                        <div class="col-12 col-md-9">
                                            <select name="floor" id="floor" class="form-control">
                                                <?php for ($i = 0; $i <= 4; $i++) {
                                                    if ($floorSlots[$i] > 0) {
                                                        echo "<option value='$i'" . ($selectedFloor == $i ? " selected" : "") . ">Floor $i (" . $floorSlots[$i] . " slots)</option>";
                                                    }
                                                } ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3"><label for="catename" class="form-control-label">Select Category</label></div>
                                        <div class="col-12 col-md-9">
                                            <select name="catename" id="catename" class="form-control" required>
                                                <option value="">Select Category</option>
                                                <?php 
                                                $query = mysqli_query($con, "SELECT * FROM tblcategory");
                                                while($row = mysqli_fetch_array($query)) {
                                                ?>
                                                <option value="<?php echo $row['VehicleCat'];?>"><?php echo $row['VehicleCat'];?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3"><label for="vehcomp" class="form-control-label">Vehicle Company</label></div>
                                        <div class="col-12 col-md-9"><input type="text" id="vehcomp" name="vehcomp" class="form-control" placeholder="Vehicle Company" required></div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3"><label for="vehreno" class="form-control-label">Registration Number</label></div>
                                        <div class="col-12 col-md-9"><input type="text" id="vehreno" name="vehreno" class="form-control" placeholder="Registration Number" required></div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3"><label for="ownername" class="form-control-label">Owner Name</label></div>
                                        <div class="col-12 col-md-9"><input type="text" id="ownername" name="ownername" class="form-control" placeholder="Owner Name" required></div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3"><label for="ownercontno" class="form-control-label">Owner Contact Number</label></div>
                                        <div class="col-12 col-md-9">
                                            <input type="text" id="ownercontno" name="ownercontno" class="form-control" 
                                                   value="<?php echo htmlspecialchars($userMobile); ?>" readonly maxlength="10" pattern="[0-9]+" required>
                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col col-md-3"><label for="parking-spaces" class="form-control-label">Available Parking Spaces</label></div>
                                        <div class="col-12 col-md-9">
                                            <div id="parking-spaces">
                                                <?php foreach ($all_numbers as $num) { ?>
                                                    <div 
                                                        class="parking-spot <?php echo in_array($num, $occupied_numbers) ? 'occupied' : 'available'; ?>"
                                                        data-parking-number="<?php echo $num; ?>"
                                                        <?php echo in_array($num, $occupied_numbers) ? '' : 'onclick="selectParkingSpot(this)"'; ?>
                                                    >
                                                        <?php echo $num; ?>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                            <input type="hidden" id="selectedParkingNumber" name="selectedParkingNumber">
                                        </div>
                                    </div>
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-primary" name="submit" id="submitBtn" disabled>Add Vehicle</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function selectParkingSpot(element) {
            const spots = document.querySelectorAll('.parking-spot');
            spots.forEach(spot => spot.classList.remove('selected'));

            element.classList.add('selected');
            document.getElementById('selectedParkingNumber').value = element.getAttribute('data-parking-number');
            document.getElementById('submitBtn').disabled = false;
        }

        $(document).ready(function() {
            $('#floor').change(function() {
                const floor = $(this).val();
                const location = '<?php echo addslashes($location); ?>';
                const parkingAt = '<?php echo addslashes($parkingAt); ?>';

                $.ajax({
                    url: 'get-parking-spots.php',
                    type: 'GET',
                    data: {
                        floor: floor,
                        location: location,
                        parkingAt: parkingAt
                    },
                    success: function(response) {
                        $('#parking-spaces').html(response);
                        // Reset selected parking number and disable submit
                        document.getElementById('selectedParkingNumber').value = '';
                        document.getElementById('submitBtn').disabled = true;
                    },
                    error: function() {
                        alert('Error fetching parking spots. Please try again.');
                    }
                });
            });
        });
    </script>
</body>
</html>
<?php } ?>