<?php
// Include PHPMailer class
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailerAutoload.php'; // Adjust path if necessary

// Create a new PHPMailer instance
$mail = new PHPMailer(true);

try {
    // Set mailer to use SMTP
    $mail->isSMTP();
    
    // Set the SMTP server to Gmail's
    $mail->Host = 'smtp.gmail.com';
    
    // Enable SMTP authentication
    $mail->SMTPAuth = true;
    
    // Set the SMTP username (your Gmail address)
    $mail->Username = 'otpsender191@gmail.com';
    
    // Set the SMTP password (use your Gmail password or app password)
    $mail->Password = 'senderotp#191'; // Use app password for better security
    
    // Enable TLS encryption
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    
    // Set the SMTP port (587 for TLS, 465 for SSL)
    $mail->Port = 587;
    
    // Set the sender's email and name
    $mail->setFrom('otpsender191@gmail.com'', 'otpsender191'');
    
    // Add a recipient
    $mail->addAddress('deveshgoswami191@gmail.com');
    
    // Set email format to HTML
    $mail->isHTML(true);
    
    // Email subject
    $mail->Subject = 'TEST';
    
    // Email body
    $mail->Body    = 'This is a testing message';
    
    // Send the email
    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>
