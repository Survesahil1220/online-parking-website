<?php
session_start();
if (!isset($_SESSION['temp_amount'])) {
    header('Location: wallet.php');
    exit();
}

$amount = $_SESSION['temp_amount'];
$qr_text = "Amount: ₹$amount"; // Text for the QR code
$qr_url = "https://qrickit.com/api/qr?data=" . urlencode($qr_text) . "&size=200";
?>

<!doctype html>
<html lang="en">
<head>
    <title>QR Code Payment</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script>
        // Countdown timer
        let countdown = 10;
        function startCountdown() {
            const timerElement = document.getElementById('countdown-timer');
            const interval = setInterval(() => {
                if (countdown <= 0) {
                    clearInterval(interval);
                    window.location.href = "wallet.php?add_amount=1"; // Redirect after countdown
                } else {
                    timerElement.textContent = countdown + " seconds";
                    countdown--;
                }
            }, 1000);
        }
    </script>
</head>
<body onload="startCountdown()">
    <div class="container mt-5">
        <h2 class="text-center">QR Code for Payment</h2>
        <div class="card mt-4 text-center">
            <div class="card-header">
                <h4>Scan the QR Code</h4>
            </div>
            <div class="card-body">
                <img src="<?php echo $qr_url; ?>" alt="QR Code">
                <p class="mt-3">Scan this QR code to add ₹<?php echo number_format($amount, 2); ?> to your wallet.</p>
                <p id="countdown-timer" class="text-danger font-weight-bold mt-3"></p>
            </div>
        </div>
    </div>
</body>
</html>
