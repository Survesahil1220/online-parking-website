<?php
session_start();
include('includes/dbconnection.php');
if(isset($_POST['login'])) {
    $_SESSION['user_id'] = $user_id; // Note: $user_id is not defined; ensure it's set earlier or remove if unnecessary
    $emailcon = $_POST['emailcont'];
    $password = md5($_POST['password']);
    $query = mysqli_query($con, "SELECT ID, MobileNumber FROM tblregusers WHERE (Email='$emailcon' || MobileNumber='$emailcon') AND Password='$password'");
    $ret = mysqli_fetch_array($query);
    if($ret > 0) {
        $_SESSION['vpmsuid'] = $ret['ID'];
        $_SESSION['vpmsumn'] = $ret['MobileNumber'];
        $_SESSION['vpmsemail'] = $emailcon; // Store email in session
        $_SESSION['user_id'] = $user_id;
        header('location: sendemail.php?sent=1');
    } else {
        header('location: login.php?error=invalid_password');
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign in Webpage</title>
    <link rel="stylesheet" href="backend.css">
    <script>
        // Check for error parameter and show alert
        window.onload = function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('error') === 'invalid_password') {
                alert('Invalid Password.');
                // Remove the error parameter from the URL to avoid repeated alerts
                window.history.replaceState({}, document.title, window.location.pathname);
            }
        };
    </script>
</head>
<body>
    <div class="container">
        <div class="sign-up">
            <h1 class="heading">Hello, User!!!</h1>
            <form method="post">
                <div class="text">
                    <img src="https://i.postimg.cc/DZBPRgvC/email.png" alt="icon" height="12">
                    <input type="text" name="emailcont" placeholder="Registered Email or Contact Number" required>
                </div>
                <div class="text">
                    <img src="https://i.postimg.cc/Nj5SDK4q/password.png" alt="icon" height="20">
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                <div class="terms">
                    <input type="checkbox" required>
                    <p class="conditions">I read and agree to <a href="#">terms & conditions</a></p>
                </div>
                <button type="submit" name="login">SIGN IN</button>
                <p class="conditions">Don't have an account? <a href="signup.php">Sign up</a></p>
                <p class="conditions"><a href="forgot-password.php">Forgotten Password?</a></p>
                <p class="conditions"><a href="../index.php">Home</a></p>
            </form>
        </div>
        <div class="text-container">
            <h1>Welcome To Our Page!!!</h1>
            <p>Welcome, please sign in to continue</p>
        </div>
    </div>
</body>
</html>