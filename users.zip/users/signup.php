<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (isset($_POST['submit'])) {
    $fname = $_POST['firstname'];
    $lname = $_POST['lastname'];
    $contno = $_POST['mobilenumber'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $ret = mysqli_query($con, "SELECT Email FROM tblregusers WHERE Email='$email' || MobileNumber='$contno'");
    $result = mysqli_fetch_array($ret);
    if ($result > 0) {
        echo '<script>alert("This email or Contact Number already associated with another account")</script>';
    } else {
        $query = mysqli_query($con, "INSERT INTO tblregusers(FirstName, LastName, MobileNumber, Email, Password) VALUE('$fname', '$lname','$contno', '$email', '$password' )");
        if ($query) {
            echo '<script>alert("You have successfully registered"); window.location.href="dashboard.php";</script>';
        } else {
            echo '<script>alert("Something Went Wrong. Please try again")</script>';
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VPMS - Signup Page</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea, #764ba2);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .container {
            max-width: 500px;
            margin-top: 2rem;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background: #667eea;
            color: #fff;
            text-align: center;
            padding: 20px;
            border-radius: 10px 10px 0 0;
        }
        .card-header h2 {
            margin: 0;
            font-weight: 700;
            font-size: 1.75rem;
        }
        .card-body {
            padding: 2rem;
        }
        .form-control {
            border-radius: 5px;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ced4da;
            transition: border-color 0.3s;
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 5px rgba(102, 126, 234, 0.3);
        }
        .btn-primary {
            background: #667eea;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 5px;
            font-weight: 600;
            transition: background 0.3s;
        }
        .btn-primary:hover {
            background: #5a6fd1;
        }
        .btn-outline-secondary {
            border-color: #764ba2;
            color: #764ba2;
            padding: 10px;
            width: 100%;
            border-radius: 5px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-outline-secondary:hover {
            background: #764ba2;
            color: #fff;
        }
        .login-link {
            text-align: center;
            margin-top: 15px;
        }
        .login-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        .footer {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
            text-align: center;
            padding: 1rem 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }
        .footer small {
            font-size: 0.9rem;
            opacity: 0.9;
        }
    </style>
    <!-- Password Validation Script -->
    <script type="text/javascript">
        function checkpass() {
            if (document.signup.password.value != document.signup.repeatpassword.value) {
                alert('Password and Repeat Password field does not match');
                document.signup.repeatpassword.focus();
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h2>VPMS - Create Your Account</h2>
                    </div>
                    <div class="card-body">
                        <form method="post" name="signup" onsubmit="return checkpass();">
                            <div class="form-group">
                                <input type="text" name="firstname" class="form-control" placeholder="First Name" required>
                            </div>
                            <div class="form-group">
                                <input type="text" name="lastname" class="form-control" placeholder="Last Name" required>
                            </div>
                            <div class="form-group">
                                <input type="text" name="mobilenumber" class="form-control" placeholder="Mobile Number" maxlength="10" pattern="[0-9]{10}" required>
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" class="form-control" placeholder="Email Address" required>
                            </div>
                            <div class="form-group">
                                <input type="password" name="password" class="form-control" placeholder="Password" required>
                            </div>
                            <div class="form-group">
                                <input type="password" name="repeatpassword" class="form-control" placeholder="Repeat Password" required>
                            </div>
                            <button type="submit" name="submit" class="btn btn-primary mb-3">Register</button>
                            
                            <div class="login-link">
                                <p>Already have an account? <a href="login.php">Login here</a></p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <small>© 2025 Space Finder | Vehicle Parking Management System</small>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>