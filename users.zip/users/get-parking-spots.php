<?php
include('includes/dbconnection.php');

$location = isset($_GET['location']) ? $_GET['location'] : '';
$parkingAt = isset($_GET['parkingAt']) ? $_GET['parkingAt'] : '';
$floor = isset($_GET['floor']) ? intval($_GET['floor']) : 0;

// Fetch floor slots
$query = mysqli_query($con, "SELECT Floor0Slots, Floor1Slots, Floor2Slots, Floor3Slots, Floor4Slots 
                            FROM tbllocation 
                            WHERE LocationName='$location' AND ParkingAt='$parkingAt'");
$locationData = mysqli_fetch_array($query);
$floorSlots = [
    0 => $locationData ? $locationData['Floor0Slots'] : 0,
    1 => $locationData ? $locationData['Floor1Slots'] : 0,
    2 => $locationData ? $locationData['Floor2Slots'] : 0,
    3 => $locationData ? $locationData['Floor3Slots'] : 0,
    4 => $locationData ? $locationData['Floor4Slots'] : 0
];

// Get slots for selected floor
$totalSlots = $floorSlots[$floor];
$all_numbers = $totalSlots > 0 ? range(1, $totalSlots) : [];

// Fetch occupied spots
$occupiedQuery = mysqli_query($con, "SELECT ParkingNumber 
                                    FROM tblvehicle 
                                    WHERE Location='$location' AND ParkingAt='$parkingAt' AND Floor='$floor' AND Status='IN'");
$occupied_numbers = [];
while ($row = mysqli_fetch_array($occupiedQuery)) {
    $occupied_numbers[] = $row['ParkingNumber'];
}

// Output parking spots HTML
echo '<div id="parking-spaces">';
foreach ($all_numbers as $num) {
    $isOccupied = in_array($num, $occupied_numbers);
    echo '<div 
            class="parking-spot ' . ($isOccupied ? 'occupied' : 'available') . '" 
            data-parking-number="' . $num . '" 
            ' . ($isOccupied ? '' : 'onclick="selectParkingSpot(this)"') . '>
            ' . $num . '
          </div>';
}
echo '</div>';
?>