<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (strlen($_SESSION['vpmsuid']) == 0) {
    header('location:logout.php');
} else {
    if (isset($_POST['submit'])) {
        $selectedLocation = $_POST['location'];
        $selectedParkingAt = $_POST['parkingAt'];

        $query = mysqli_query($con, "SELECT ID FROM tbllocation WHERE LocationName='$selectedLocation' AND ParkingAt='$selectedParkingAt'");
        $row = mysqli_fetch_array($query);
        $adminId = $row['ID'];

        header("Location: add-vehicle.php?location=$selectedLocation&parkingAt=$selectedParkingAt&adminId=$adminId");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SpaceFinder - Search Location</title>

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />

    <!-- Custom Styles -->
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --text-color: #333;
            --bg-color: #f5f6fa;
            --sidebar-gradient-start: #2c3e50;
            --sidebar-gradient-end: #34495e;
            --border-color: #d1dce5;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }

        .left-panel {
            background: linear-gradient(135deg, var(--sidebar-gradient-start), var(--sidebar-gradient-end));
            height: 100vh;
            position: fixed;
            width: 250px;
            box-shadow: 3px 0 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            overflow-y: auto;
            top: 0;
            left: 0;
        }

        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }

        .sidebar-title {
            color: #fff;
            font-size: 24px;
            font-weight: 700;
            margin: 0;
            letter-spacing: 1px;
        }

        .navbar-nav {
            padding: 20px 0;
        }

        .nav-item {
            margin: 5px 0;
            position: relative;
        }

        .nav-link {
            color: #fff !important;
            padding: 15px 25px !important;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            border-radius: 0 25px 25px 0;
            font-weight: 500;
        }

        .nav-link:hover, .nav-link.active {
            background: var(--secondary-color);
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .nav-item.active .nav-link {
            background: var(--secondary-color);
        }

        .menu-icon {
            margin-right: 15px;
            font-size: 20px;
            width: 25px;
            text-align: center;
        }

        .right-panel {
            margin-left: 250px;
            padding-top: 70px;
        }

        .header {
            position: fixed;
            top: 0;
            left: 250px;
            right: 0;
            z-index: 1000;
            background: #fff;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .breadcrumbs {
            background: #fff;
            padding: 15px 30px;
            border-bottom: 1px solid var(--border-color);
            margin: 20px 0;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .breadcrumb {
            background: none;
            padding: 0;
            margin: 0;
        }

        .breadcrumb-item a {
            color: var(--secondary-color);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .breadcrumb-item a:hover {
            color: var(--primary-color);
        }

        .breadcrumb-item.active {
            color: var(--text-color);
            font-weight: 500;
        }

        .content {
            padding: 0 30px 30px;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        .card-header {
            background: var(--primary-color);
            color: #fff;
            padding: 15px 20px;
            font-size: 18px;
            font-weight: 600;
            border-bottom: none;
        }

        .card-body {
            padding: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-control-label {
            font-weight: 600;
            color: var(--primary-color);
        }

        .form-control {
            border: 1px solid var(--border-color);
            border-radius: 5px;
            padding: 10px;
            transition: border-color 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 5px rgba(52, 152, 219, 0.5);
        }

        .select2-container--default .select2-selection--single {
            border: 1px solid var(--border-color);
            border-radius: 5px;
            height: 38px;
            padding: 5px;
        }

        .select2-container--default .select2-selection--single:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 5px rgba(52, 152, 219, 0.5);
        }

        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 28px;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 36px;
        }

        #mapFrame {
            border: 1px solid var(--border-color);
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .btn-primary {
            background: var(--secondary-color);
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: 500;
            transition: background 0.3s ease;
        }

        .btn-primary:hover {
            background: #2980b9;
        }

        @media (max-width: 768px) {
            .left-panel {
                width: 70px;
            }

            .right-panel {
                margin-left: 70px;
            }

            .header {
                left: 70px;
            }

            .content {
                padding: 0 15px 15px;
            }

            .breadcrumbs {
                padding: 10px 15px;
                margin: 10px 0;
            }

            .form-group {
                margin-bottom: 15px;
            }

            .col-md-3 {
                margin-bottom: 10px;
            }

            #mapFrame {
                height: 150px;
            }
        }
    </style>
</head>
<body>
    <?php include_once('includes/sidebar.php'); ?>
    <?php include_once('includes/header.php'); ?>

    <div class="right-panel">
        <div class="breadcrumbs">
            <div class="container-fluid">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="Search-location.php">Search Location</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Find Parking</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="content">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <strong>Search Location for Parking</strong>
                            </div>
                            <div class="card-body">
                                <form action="" method="post" class="form-horizontal">
                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label class="form-control-label">Select Location</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <select name="location" id="locationSelect" class="form-control select2" required>
                                                <option value="">Select Location</option>
                                                <?php
                                                $query = mysqli_query($con, "SELECT DISTINCT LocationName FROM tbllocation ORDER BY LocationName ASC");
                                                while ($row = mysqli_fetch_array($query)) {
                                                ?>
                                                <option value="<?php echo $row['LocationName']; ?>">
                                                    <?php echo $row['LocationName']; ?>
                                                </option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label class="form-control-label">Select Parking</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <select name="parkingAt" id="parkingAtSelect" class="form-control select2" required>
                                                <option value="">Select Parking</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="row form-group">
                                        <div class="col col-md-3">
                                            <label class="form-control-label">View on Map</label>
                                        </div>
                                        <div class="col-12 col-md-9">
                                            <iframe id="mapFrame" src="" width="100%" height="200" style="display:none;"></iframe>
                                        </div>
                                    </div>

                                    <div class="text-center">
                                        <button type="submit" class="btn btn-primary" name="submit">Book Now</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <script>
    $(document).ready(function() {
        $("#locationSelect").select2({
            placeholder: "Search or Select Location",
            allowClear: true
        });

        $("#parkingAtSelect").select2({
            placeholder: "Select Parking",
            allowClear: true
        });

        $("#locationSelect").change(function() {
            var selectedLocation = $(this).val();
            $("#parkingAtSelect").empty().append('<option value="">Select Parking</option>');
            
            if (selectedLocation) {
                <?php
                $query = mysqli_query($con, "SELECT DISTINCT LocationName, ParkingAt, Latitude, Longitude FROM tbllocation ORDER BY LocationName ASC");
                $locations = [];
                while ($row = mysqli_fetch_array($query)) {
                    $locations[$row['LocationName']][] = [
                        'ParkingAt' => $row['ParkingAt'],
                        'Latitude' => $row['Latitude'],
                        'Longitude' => $row['Longitude']
                    ];
                }
                ?>
                var locations = <?php echo json_encode($locations); ?>;
                var parkings = locations[selectedLocation];
                
                parkings.forEach(function(parking) {
                    $("#parkingAtSelect").append(
                        '<option value="' + parking.ParkingAt + '" data-lat="' + parking.Latitude + '" data-lng="' + parking.Longitude + '">' + 
                        parking.ParkingAt + 
                        '</option>'
                    );
                });
            }
        });

        $("#parkingAtSelect").change(function() {
            var selectedOption = $(this).find(":selected");
            var lat = selectedOption.data("lat");
            var lng = selectedOption.data("lng");

            if (lat && lng) {
                var mapUrl = `https://www.google.com/maps/embed/v1/place?key=AIzaSyDcnXfNb71hiCIiE9_S04qdWszjkcRtLuM&q=${lat},${lng}`;
                $("#mapFrame").attr("src", mapUrl).show();
            } else {
                $("#mapFrame").hide();
            }
        });
    });
    </script>
</body>
</html>