<?php
session_start();
include('includes/dbconnection.php');

// Simulate user session (replace with your actual session logic)
$user_id = $_SESSION['vpmsuid'] ?? 1; // Replace this with dynamic user ID from session

// Fetch wallet balance
$query = mysqli_query($con, "SELECT balance FROM tblregusers WHERE ID = '$user_id'");
$wallet = mysqli_fetch_array($query);
$current_balance = $wallet['balance'] ?? 0.00;


// Check if QR was confirmed
if (isset($_GET['confirmed_amount'])) {
    $confirmed_amount = floatval($_GET['confirmed_amount']);
    if ($confirmed_amount > 0) {
        // Update the wallet balance
        mysqli_query($con, "UPDATE tblregusers SET balance = balance + $confirmed_amount WHERE ID = '$user_id'");
        echo "<script>alert('₹$confirmed_amount successfully added to your wallet!');</script>";
    }
    header('Location: wallet.php'); // Redirect to the wallet page to show the updated balance
    exit();
}

// Handle Add Money QR functionality
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['action'] === 'add') {
    $amount = floatval($_POST['amount']);

    if ($amount > 0) {
        // Generate QR Code URL using QRickit API
        $qr_url = "https://qrickit.com/api/qr.php?d=Add%20₹$amount%20to%20your%20wallet.&addtext=VPMS%20Wallet&txtcolor=000000&fgdcolor=333399";

        // Show QR Code and initiate countdown
        echo "<!doctype html>
        <html lang='en'>
        <head>
            <title>QR Code Payment</title>
            <script>
                // Countdown timer
                let seconds = 10;
                const countdown = setInterval(() => {
                    if (seconds > 0) {
                        document.getElementById('countdown').innerText = seconds + ' seconds remaining...';
                        seconds--;
                    } else {
                        clearInterval(countdown);
                        // Redirect back to wallet with confirmation
                        window.location.href = 'wallet.php?confirmed_amount=$amount';
                    }
                }, 1000);
            </script>
        </head>
        <body>
            <div style='text-align: center; margin-top: 50px;'>
                <h2>Scan the QR Code to Add ₹$amount</h2>
                <img src='$qr_url' alt='QR Code'><br>
                <p id='countdown' style='font-size: 20px; color: red;'></p>
            </div>
        </body>
        </html>";
        exit();
    } else {
        echo "<script>alert('Enter a valid amount!');</script>";
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <title>Wallet Management</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/wallet.css">
    
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center">Wallet Management</h2>
    <div class="card mt-4">
        <div class="card-header">
            <h4>Your Wallet</h4>
        </div>
        <div class="card-body">
            <p><strong>Current Balance:</strong> ₹<?php echo number_format($current_balance, 2); ?></p>
            <form method="post" class="mt-4">
                <div class="form-group">
                    <label for="amount">Enter Amount:</label>
                    <input type="number" step="0.01" name="amount" id="amount" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Action:</label><br>
                    <button type="submit" name="action" value="add" class="btn btn-success">Add Money</button>
                </div>
            </form>
        </div>
    </div>
    <a href="dashboard.php" class="btn btn-primary mt-3">Back to Dashboard</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.3.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
</body>
</html>
