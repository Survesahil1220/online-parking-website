<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['vpmsuid']) == 0) {
    header('location:logout.php');
} else { ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SpaceFinder - Dashboard</title>
    
    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    
    <!-- Custom Styles -->
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --text-color: #333;
            --bg-color: #f5f6fa;
            --sidebar-gradient-start: #2c3e50;
            --sidebar-gradient-end: #34495e;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: var(--bg-color);
            color: var(--text-color);
            line-height: 1.6;
        }

        /* Sidebar Styles */
        .left-panel {
            background: linear-gradient(135deg, var(--sidebar-gradient-start), var(--sidebar-gradient-end));
            height: 100vh;
            position: fixed;
            width: 250px;
            box-shadow: 3px 0 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            text-align: center;
        }

        .sidebar-title {
            color: #fff;
            font-size: 24px;
            font-weight: 700;
            margin: 0;
            letter-spacing: 1px;
        }

        .navbar-nav {
            padding: 20px 0;
        }

        .nav-item {
            margin: 5px 0;
            position: relative;
        }

        .nav-link {
            color: #fff !important;
            padding: 15px 25px !important;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            border-radius: 0 25px 25px 0;
            font-weight: 500;
        }

        .nav-link:hover, .nav-link.active {
            background: var(--secondary-color);
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .nav-item.active .nav-link {
            background: var(--secondary-color);
        }

        .menu-icon {
            margin-right: 15px;
            font-size: 20px;
            width: 25px;
            text-align: center;
        }

        /* Header Styles */
        .right-panel {
            margin-left: 250px;
        }

        .header {
            background: #fff;
            padding: 15px 30px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar-header {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-color) !important;
        }

        .balance-container {
            margin-right: 20px;
        }

        .balance-badge {
            background: #fff !important;
            color: #27ae60 !important;
            font-size: 16px !important;
            padding: 8px 15px !important;
            border: 2px solid #27ae60;
            font-weight: 600 !important;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border: 2px solid var(--secondary-color);
            padding: 2px;
        }

        .dropdown-menu {
            background: #fff;
            border: none;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-radius: 8px;
            min-width: 180px;
        }

        .dropdown-menu .nav-link {
            color: var(--text-color) !important;
            padding: 10px 20px !important;
            transition: all 0.3s ease;
        }

        .dropdown-menu .nav-link:hover {
            background: var(--secondary-color);
            color: #fff !important;
            padding-left: 25px !important;
        }
/*sssssssssssssssssssssssssssssssssssssssssssssssssssssssssss */
        /* Content Styles */
        .content {
            margin-left: 250px;
            padding: 30px;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            margin-bottom: 20px;
        }

        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.1);
            cursor: pointer;
        }

        .stat-widget-five {
            padding: 20px;
            display: flex;
            align-items: center;
        }

        .stat-icon {
            font-size: 20px;
            color: var(--secondary-color);
            margin-right: 10px;
            background: rgba(52, 152, 219, 0.1);
            padding: 8px;
            border-radius: 50%;
        }

        .stat-card {
            background: #fff;
            padding: 15px;
            display: flex;
            align-items: center;
        }

        .stat-number {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-color);
            margin: 0;
        }

        .stat-label {
            font-size: 14px;
            color: #666;
            margin-left: 10px;
        }

        .stat-link {
            text-decoration: none;
            color: inherit;
            display: flex;
            align-items: center;
            width: 100%;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .left-panel {
                width: 70px;
            }

            .right-panel, .content {
                margin-left: 70px;
            }

            .sidebar-title, .nav-link span {
                display: none;
            }

            .nav-link {
                justify-content: center;
                padding: 15px !important;
            }

            .menu-icon {
                margin-right: 0;
            }
        }
    </style>
</head>
<body>
<?php include_once('includes/sidebar.php'); ?>
    <?php include_once('includes/header.php'); ?>

    <!-- Content -->
    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12 col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="stat-widget-five">
                                <?php
                                $uid = $_SESSION['vpmsuid'];
                                $ret = mysqli_query($con, "select * from tblregusers where ID='$uid'");
                                while ($row = mysqli_fetch_array($ret)) {
                                ?>
                                <div class="stat-icon">
                                    <i class="fa fa-user-circle"></i>
                                </div>
                                <div class="stat-content">
                                    <h4>Welcome back, <?php echo $row['FirstName']; ?> <?php echo $row['LastName']; ?>!</h4>
                                    <p>Your parking management dashboard</p>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Smaller Card for Vehicles Parked with Link -->
                <div class="col-lg-3 col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <a href="view-vehicle.php" class="stat-link">
                                <div class="stat-card">
                                    <div class="stat-icon">
                                        <i class="fa fa-car"></i>
                                    </div>
                                    <?php
                                    $uid = $_SESSION['vpmsuid'];
                                    $vehicle_query = mysqli_query($con, "SELECT COUNT(*) as total_vehicles FROM tblvehicle WHERE OwnerContactNumber = (SELECT MobileNumber FROM tblregusers WHERE ID='$uid')");
                                    $vehicle_data = mysqli_fetch_array($vehicle_query);
                                    $total_vehicles = $vehicle_data['total_vehicles'];
                                    ?>
                                    <p class="stat-number"><?php echo $total_vehicles; ?></p>
                                    <p class="stat-label">Vehicles Parked</p>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> <!-- Closing right-panel div from header -->

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php } ?>