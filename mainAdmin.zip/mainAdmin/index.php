<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if(isset($_POST['login']))
  {
    $adminuser=$_POST['username'];
    $password=md5($_POST['password']);
    $query=mysqli_query($con,"select ID from tblmainadmin where  UserName='$adminuser' && Password='$password' ");
    $ret=mysqli_fetch_array($query);
    if($ret>0){
      $_SESSION['vpmsaid']=$ret['ID'];
     header('location:dashboard.php');
    }
    else{
  
     echo "<script>alert('Invalid Details.');</script>";
    }
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SpaceFinder - Main Admin Login</title>

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">

    <!-- Custom Styles -->
    <style>
        :root {
            --primary-color: #1a2a6c; /* Deep blue for main admin */
            --secondary-color: #b21f1f; /* Rich red accent */
            --text-color: #333;
            --bg-color: #f0f4f8; /* Light grayish-blue background */
            --card-bg: #ffffff;
            --border-color: #e0e4e8;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(135deg, var(--bg-color), #d9e2ec);
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-container {
            width: 100%;
            max-width: 400px;
            background: var(--card-bg);
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            padding: 40px;
            text-align: center;
        }

        .login-header {
            margin-bottom: 30px;
        }

        .login-header h1 {
            font-size: 28px;
            color: var(--primary-color);
            font-weight: 700;
            margin: 0;
        }

        .login-header p {
            font-size: 16px;
            color: #666;
            margin-top: 5px;
        }

        .form-group {
            position: relative;
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            font-size: 14px;
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 5px;
            display: block;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: #fafafa;
        }

        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 8px rgba(178, 31, 31, 0.3);
            outline: none;
            background: #fff;
        }

        .checkbox {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
        }

        .conditions {
            font-size: 14px;
            color: var(--text-color);
            margin: 0;
        }

        .conditions a {
            color: var(--secondary-color);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .conditions a:hover {
            color: var(--primary-color);
            text-decoration: underline;
        }

        button[type="submit"] {
            width: 100%;
            padding: 14px;
            background: var(--secondary-color);
            border: none;
            border-radius: 8px;
            color: #fff;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button[type="submit"]:hover {
            background: #a01b1b;
        }

        .home-link {
            margin-top: 20px;
            text-align: center;
        }

        .home-link a {
            font-size: 14px;
            color: var(--secondary-color);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .home-link a:hover {
            color: var(--primary-color);
            text-decoration: underline;
        }

        @media (max-width: 576px) {
            .login-container {
                width: 90%;
                padding: 20px;
            }

            .login-header h1 {
                font-size: 24px;
            }

            .login-header p {
                font-size: 14px;
            }

            button[type="submit"] {
                padding: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1>Main Admin Login</h1>
            <p>Access the Vehicle Parking Management System</p>
        </div>
        <form method="post">
            <div class="form-group">
                <label>User Name</label>
                <input class="form-control" type="text" placeholder="Username" required="true" name="username">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" name="password" placeholder="Password" required="true">
            </div>
            
            <button type="submit" name="login">Sign In</button>
            <div class="home-link">
                <a href="../index.php">Home</a>
            </div>
        </form>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>