<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

// Check if main admin is logged in
if (strlen($_SESSION['vpmsaid']) == 0) {
    header('location:logout.php');
} else {
    // Function to extract coordinates from Google Maps URL
    function extractCoordinates($url) {
        $pattern = "/@([-0-9.]+),([-0-9.]+)/";
        preg_match($pattern, $url, $matches);
        if (!empty($matches)) {
            return ["latitude" => $matches[1], "longitude" => $matches[2]];
        } else {
            return ["error" => "Invalid Google Maps URL"];
        }
    }

    if (isset($_POST['submit'])) {
        // Location Details
        $locationName = $_POST['locationname'];
        $parkingAt = $_POST['parkingat'];
        $address = $_POST['address'];
        $city = $_POST['city'];
        $state = $_POST['state'];
        $country = $_POST['country'];
        $zipcode = $_POST['zipcode'];
        $parkingSlots = (int)$_POST['parkingslots'];

        // Floor Slots
        $floor0Slots = (int)$_POST['floor0slots'];
        $floor1Slots = (int)$_POST['floor1slots'];
        $floor2Slots = (int)$_POST['floor2slots'];
        $floor3Slots = (int)$_POST['floor3slots'];
        $floor4Slots = (int)$_POST['floor4slots'];

        // Validate floor slots sum
        $totalFloorSlots = $floor0Slots + $floor1Slots + $floor2Slots + $floor3Slots + $floor4Slots;
        if ($totalFloorSlots !== $parkingSlots) {
            echo "<script>alert('Error: The sum of floor slots ($totalFloorSlots) must equal the total parking slots ($parkingSlots).');</script>";
        } else {
            // Handle latitude and longitude
            if (!empty($_POST['map_url'])) {
                $coordinates = extractCoordinates($_POST['map_url']);
                if (!isset($coordinates['error'])) {
                    $latitude = $coordinates['latitude'];
                    $longitude = $coordinates['longitude'];
                } else {
                    $latitude = $_POST['latitude'];
                    $longitude = $_POST['longitude'];
                }
            } else {
                $latitude = $_POST['latitude'];
                $longitude = $_POST['longitude'];
            }

            // Admin Details
            $adminName = $_POST['adminname'];
            $userName = $_POST['username'];
            $mobileNumber = $_POST['mobilenumber'];
            $email = $_POST['email'];
            $password = md5($_POST['password']);

            // Insert into tbllocation with floor slots
            $locationQuery = mysqli_query($con, "INSERT INTO tbllocation (LocationName, ParkingAt, Address, City, State, Country, ZipCode, ParkingSlotsAvailable, Latitude, Longitude, Floor0Slots, Floor1Slots, Floor2Slots, Floor3Slots, Floor4Slots) 
                                                VALUES ('$locationName', '$parkingAt', '$address', '$city', '$state', '$country', '$zipcode', '$parkingSlots', '$latitude', '$longitude', '$floor0Slots', '$floor1Slots', '$floor2Slots', '$floor3Slots', '$floor4Slots')");
            
            if ($locationQuery) {
                $locationId = mysqli_insert_id($con);
                $adminQuery = mysqli_query($con, "INSERT INTO tbladmin (AdminName, UserName, MobileNumber, Email, Password, AssignedParkingAt) 
                                                VALUES ('$adminName', '$userName', '$mobileNumber', '$email', '$password', '$parkingAt')");

                if ($adminQuery) {
                    echo "<script>alert('Location and admin added successfully.');</script>";
                    echo "<script>window.location.href='dashboard.php';</script>";
                } else {
                    echo "<script>alert('Failed to add admin. Please try again.');</script>";
                }
            } else {
                echo "<script>alert('Failed to add location. Please try again.');</script>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SpaceFinder - Add Location</title>

    <!-- Core CSS from Reference -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text'>

    <!-- Custom Styles -->
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --text-color: #333;
            --bg-color: #f5f6fa;
            --card-bg: #ffffff;
            --border-color: #d1dce5;
        }

        body {
            font-family: 'Open Sans', sans-serif;
            background: var(--bg-color);
            margin: 0;
            padding: 0;
        }

        .content {
            margin-left: 35px;
            padding: 30px;
            min-height: calc(100vh - 60px);
        }

        .breadcrumbs {
            background: var(--card-bg);
            padding: 15px 20px;
            border-bottom: 1px solid var(--border-color);
            margin-bottom: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .breadcrumb {
            background: none;
            padding: 0;
            margin: 0;
        }

        .breadcrumb-item a {
            color: var(--secondary-color);
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .breadcrumb-item a:hover {
            color: var(--primary-color);
        }

        .breadcrumb-item.active {
            color: var(--text-color);
            font-weight: 500;
        }

        .card {
            border: none;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow: hidden;
        }

        .card-header {
            background: var(--primary-color);
            color: #fff;
            padding: 15px 20px;
            font-size: 18px;
            font-weight: 600;
            border-bottom: none;
        }

        .card-body {
            padding: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-control-label {
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 5px;
            display: block;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 5px rgba(52, 152, 219, 0.5);
            outline: none;
        }

        .section-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--secondary-color);
            margin: 20px 0 10px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 5px;
        }

        .btn-primary {
            background: var(--secondary-color);
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            color: #fff;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .btn-primary:hover {
            background: #2980b9;
        }

        .error-message {
            color: red;
            font-size: 12px;
            margin-top: 5px;
            display: none;
        }

        @media (max-width: 768px) {
            .content {
                margin-left: 70px;
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <?php include_once('includes/sidebar.php'); ?>
    <?php include_once('includes/header.php'); ?>

    <div class="content">
        <div class="breadcrumbs">
            <div class="container-fluid">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Add Location</li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Add New Location</strong>
                        </div>
                        <div class="card-body">
                            <form method="post" id="locationForm">
                                <!-- Location Details Section -->
                                <div class="section-title">Location Details</div>
                                <div class="form-group">
                                    <label class="form-control-label">Location Name</label>
                                    <input class="form-control" type="text" name="locationname" placeholder="e.g., Downtown Parking" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Parking At</label>
                                    <input class="form-control" type="text" name="parkingat" placeholder="e.g., Los Angeles Mall" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Address</label>
                                    <input class="form-control" type="text" name="address" placeholder="Street Address" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">City</label>
                                    <input class="form-control" type="text" name="city" placeholder="City" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">State</label>
                                    <input class="form-control" type="text" name="state" placeholder="State" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Country</label>
                                    <input class="form-control" type="text" name="country" placeholder="Country" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Zip Code</label>
                                    <input class="form-control" type="text" name="zipcode" placeholder="Zip Code" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Total Parking Slots Available</label>
                                    <input class="form-control" type="number" name="parkingslots" id="parkingslots" placeholder="Total Number of Slots" min="1" required="true">
                                </div>
                                <div class="section-title">Floor-wise Parking Slots</div>
                                <div class="form-group">
                                    <label class="form-control-label">Floor 0 Slots</label>
                                    <input class="form-control floor-slot" type="number" name="floor0slots" id="floor0slots" placeholder="Slots on Floor 0" min="0" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Floor 1 Slots</label>
                                    <input class="form-control floor-slot" type="number" name="floor1slots" id="floor1slots" placeholder="Slots on Floor 1" min="0" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Floor 2 Slots</label>
                                    <input class="form-control floor-slot" type="number" name="floor2slots" id="floor2slots" placeholder="Slots on Floor 2" min="0" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Floor 3 Slots</label>
                                    <input class="form-control floor-slot" type="number" name="floor3slots" id="floor3slots" placeholder="Slots on Floor 3" min="0" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Floor 4 Slots</label>
                                    <input class="form-control floor-slot" type="number" name="floor4slots" id="floor4slots" placeholder="Slots on Floor 4" min="0" required="true">
                                    <div class="error-message" id="floor-error">The sum of floor slots must equal the total parking slots.</div>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Google Maps URL (Optional)</label>
                                    <input class="form-control" type="text" name="map_url" id="map_url" placeholder="e.g., https://www.google.com/maps/@34.052235,-118.243683,14z" onchange="fetchCoordinates()">
                                    <small class="form-text text-muted">Paste a Google Maps URL to auto-fill latitude and longitude.</small>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Latitude</label>
                                    <input class="form-control" type="text" name="latitude" id="latitude" placeholder="" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Longitude</label>
                                    <input class="form-control" type="text" name="longitude" id="longitude" placeholder="" required="true">
                                </div>

                                <!-- Admin Details Section -->
                                <div class="section-title">Assigned Admin Details</div>
                                <div class="form-group">
                                    <label class="form-control-label">Admin Name</label>
                                    <input class="form-control" type="text" name="adminname" placeholder="Full Name" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">User Name</label>
                                    <input class="form-control" type="text" name="username" placeholder="Username" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Mobile Number</label>
                                    <input class="form-control" type="text" name="mobilenumber" placeholder="Mobile Number" maxlength="10" pattern="[0-9]{10}" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Email</label>
                                    <input class="form-control" type="email" name="email" placeholder="Email Address" required="true">
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Password</label>
                                    <input class="form-control" type="password" name="password" placeholder="Password" required="true">
                                </div>

                                <!-- Submit Button -->
                                <div class="text-center">
                                    <button type="submit" name="submit" class="btn btn-primary">Add Location</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts from Reference -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script>
        // Client-side validation for floor slots
        document.getElementById('locationForm').addEventListener('submit', function(event) {
            const totalSlots = parseInt(document.getElementById('parkingslots').value) || 0;
            const floor0 = parseInt(document.getElementById('floor0slots').value) || 0;
            const floor1 = parseInt(document.getElementById('floor1slots').value) || 0;
            const floor2 = parseInt(document.getElementById('floor2slots').value) || 0;
            const floor3 = parseInt(document.getElementById('floor3slots').value) || 0;
            const floor4 = parseInt(document.getElementById('floor4slots').value) || 0;
            const totalFloorSlots = floor0 + floor1 + floor2 + floor3 + floor4;
            const errorMessage = document.getElementById('floor-error');

            if (totalFloorSlots !== totalSlots) {
                event.preventDefault();
                errorMessage.style.display = 'block';
                errorMessage.textContent = `The sum of floor slots (${totalFloorSlots}) must equal the total parking slots (${totalSlots}).`;
            } else {
                errorMessage.style.display = 'none';
            }
        });

        // Real-time sum calculation for user feedback
        const floorInputs = document.querySelectorAll('.floor-slot');
        floorInputs.forEach(input => {
            input.addEventListener('input', () => {
                const totalSlots = parseInt(document.getElementById('parkingslots').value) || 0;
                const floor0 = parseInt(document.getElementById('floor0slots').value) || 0;
                const floor1 = parseInt(document.getElementById('floor1slots').value) || 0;
                const floor2 = parseInt(document.getElementById('floor2slots').value) || 0;
                const floor3 = parseInt(document.getElementById('floor3slots').value) || 0;
                const floor4 = parseInt(document.getElementById('floor4slots').value) || 0;
                const totalFloorSlots = floor0 + floor1 + floor2 + floor3 + floor4;
                const errorMessage = document.getElementById('floor-error');

                if (totalFloorSlots !== totalSlots) {
                    errorMessage.style.display = 'block';
                    errorMessage.textContent = `Sum: ${totalFloorSlots}. Must equal ${totalSlots}.`;
                } else {
                    errorMessage.style.display = 'none';
                }
            });
        });

        function fetchCoordinates() {
            const mapUrl = document.getElementById('map_url').value;
            if (mapUrl) {
                const coordinates = extractCoordinatesFromUrl(mapUrl);
                if (coordinates.latitude && coordinates.longitude) {
                    document.getElementById('latitude').value = coordinates.latitude;
                    document.getElementById('longitude').value = coordinates.longitude;
                } else {
                    alert('Invalid Google Maps URL. Please enter manually or correct the URL.');
                }
            }
        }

        // Client-side coordinate extraction
        function extractCoordinatesFromUrl(url) {
            const pattern = /@([-0-9.]+),([-0-9.]+)/;
            const matches = url.match(pattern);
            if (matches) {
                return { latitude: matches[1], longitude: matches[2] };
            }
            return {};
        }
    </script>
</body>
</html>