<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if(isset($_POST['submit']))
  {
    $contactno=$_POST['contactno'];
    $email=$_POST['email'];

    $query=mysqli_query($con,"select ID from tbladmin where  Email='$email' and MobileNumber='$contactno' ");
    $ret=mysqli_fetch_array($query);
    if($ret>0){
      $_SESSION['contactno']=$contactno;
      $_SESSION['email']=$email;
      header('location:reset-password.php');
    }
    else{
      echo "<script>alert('Invalid Details. Please try again.');</script>";
    }
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SpaceFinder - Forgot Password</title>

    <!-- Core CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">

    <!-- Custom Styles -->
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --text-color: #333;
            --bg-color: #f5f6fa;
            --light-bg: #ffffff;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: var(--bg-color);
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            display: flex;
            width: 80%;
            max-width: 900px;
            background: var(--light-bg);
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .sign-up {
            flex: 1;
            padding: 40px;
            background: var(--light-bg);
        }

        .text-container {
            flex: 1;
            padding: 40px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
        }

        .heading {
            font-size: 28px;
            color: var(--primary-color);
            margin-bottom: 20px;
        }

        .text-container h1 {
            font-size: 32px;
            margin-bottom: 10px;
        }

        .text-container p {
            font-size: 18px;
            opacity: 0.9;
        }

        .form-group {
            position: relative;
            margin-bottom: 20px;
        }

        .form-group img {
            position: absolute;
            top: 50%;
            left: 10px;
            transform: translateY(-50%);
            height: 20px;
            opacity: 0.7;
            
        }

        .form-control {
            width: 100%;
            padding: 12px 12px 12px 40px;
            border: 1px solid var(--border-color, #d1dce5);
            border-radius: 5px;
            font-size: 16px;
            transition: border-color 0.3s ease;
            margin-left: 6px;
        }

        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 5px rgba(52, 152, 219, 0.5);
            outline: none;
        }

        .checkbox {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .checkbox input {
            margin-right: 10px;
        }

        .conditions {
            font-size: 14px;
            color: var(--text-color);
            margin: 0;
        }

        .conditions a {
            color: var(--secondary-color);
            text-decoration: none;
        }

        .conditions a:hover {
            color: var(--primary-color);
            text-decoration: underline;
        }

        .pull-right {
            margin-left: auto;
        }

        button[type="submit"] {
            width: 100%;
            padding: 12px;
            background: var(--secondary-color);
            border: none;
            border-radius: 5px;
            color: #fff;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button[type="submit"]:hover {
            background: #2980b9;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                width: 90%;
            }

            .sign-up, .text-container {
                padding: 20px;
            }

            .text-container {
                display: none; /* Hide welcome message on small screens */
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sign-up">
            <h1 class="heading">Forgot Password</h1>
            <form method="post">
                <div class="form-group">
                    <img src="https://i.postimg.cc/DZBPRgvC/email.png" alt="icon" height="12">
                    <input type="text" class="form-control" name="email" placeholder="Email" autofocus required="true">
                </div>
                <div class="form-group">
                    <img src="https://i.postimg.cc/Nj5SDK4q/password.png" alt="icon" height="20">
                    <input type="text" class="form-control" name="contactno" placeholder="Mobile Number" required="true">
                </div>
                <div class="checkbox">
                    <label class="pull-right conditions">
                        <a href="index.php">Sign In</a>
                    </label>
                </div>
                <button type="submit" name="submit">Reset</button>
            </form>
        </div>
        <div class="text-container">
            <h1>Reset Your Password</h1>
            <p>Enter your email and mobile number to recover your admin account</p>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>