<?php
session_start();
include('includes/dbconnection.php');

if (!isset($_SESSION['vpmsaid'])) {
    header('location:logout.php');
    exit();
}

// Get the current admin's ID from session
$adminId = $_SESSION['vpmsaid'];

// Get the admin's details (for display)
$adminQuery = mysqli_query($con, "SELECT AdminName, AssignedParkingAt FROM tbladmin WHERE ID = '$adminId'");
$adminData = mysqli_fetch_array($adminQuery);
$adminName = $adminData['AdminName'];
$assignedParkingAt = $adminData['AssignedParkingAt'];

// Handle deletion
if (isset($_GET['del'])) {
    $catid = $_GET['del'];
    $deleteQuery = mysqli_query($con, "DELETE FROM tblvehicle WHERE ID ='$catid' AND AdminID = '$adminId'");
    if (mysqli_affected_rows($con) > 0) {
        echo "<script>alert('Data Deleted');</script>";
    } else {
        echo "<script>alert('You can only delete vehicles you added');</script>";
    }
    echo "<script>window.location.href='manage-incomingvehicle.php'</script>";
}
?>
<!doctype html>
<html class="no-js" lang="">
<head>
    <title>VPMS - Manage Incoming Vehicle</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
</head>
<body>
    <?php include_once('includes/sidebar.php');?>
    <?php include_once('includes/header.php');?>

    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Dashboard</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="dashboard.php">Dashboard</a></li>
                                <li><a href="manage-incomingvehicle.php">Manage Vehicle</a></li>
                                <li class="active">Manage Incoming Vehicle</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Manage Incoming Vehicle - <?php echo htmlspecialchars($assignedParkingAt); ?> (Admin: <?php echo htmlspecialchars($adminName); ?>)</strong>
                        </div>
                        <div class="card-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>S.NO</th>
                                        <th>Parking Number</th>
                                        <th>Floor</th>
                                        <th>Owner Name</th>
                                        <th>Vehicle Reg Number</th>
                                        <th>Location</th>
                                        <th>Parking Area</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                // Filter vehicles by AdminID and Status='IN' or empty (incoming vehicles)
                                $ret = mysqli_query($con, "SELECT * FROM tblvehicle WHERE (Status='IN' OR Status='') AND AdminID = '$adminId' ORDER BY ParkingNumber");
                                
                                $cnt = 1;
                                if (mysqli_num_rows($ret) == 0) {
                                    echo "<tr><td colspan='8' class='text-center'>No incoming vehicles found for this admin.</td></tr>";
                                }
                                while ($row = mysqli_fetch_array($ret)) {
                                ?>
                                <tr>
                                    <td><?php echo $cnt;?></td>
                                    <td><?php echo htmlspecialchars($row['ParkingNumber']);?></td>
                                    <td><?php echo ($row['Floor'] !== null) ? htmlspecialchars($row['Floor']) : '-';?></td>
                                    <td><?php echo htmlspecialchars($row['OwnerName']);?></td>
                                    <td><?php echo htmlspecialchars($row['RegistrationNumber']);?></td>
                                    <td><?php echo htmlspecialchars($row['Location']);?></td>
                                    <td><?php echo htmlspecialchars($row['ParkingAt']);?></td>
                                    <td>
                                        <a href="view-incomingvehicle-detail.php?viewid=<?php echo $row['ID'];?>" class="btn btn-primary">View</a>
                                        <a href="print.php?vid=<?php echo $row['ID'];?>" style="cursor:pointer" target="_blank" class="btn btn-warning">Print</a>
                                        <a href="manage-incomingvehicle.php?del=<?php echo $row['ID'];?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete?')">Delete</a>
                                    </td>
                                </tr>
                                <?php 
                                    $cnt++;
                                }?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- .animated -->
    </div><!-- .content -->

    <div class="clearfix"></div>

    <?php include_once('includes/footer.php');?>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>