<style>
    /* Fixed Footer CSS */
    html, body {
        height: 100%;
        margin: 0;
    }

    body {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    .content {
        flex: 1 0 auto;
    }

    .site-footer {
        flex-shrink: 0;
        background-color: white;
        padding: 15px 0;
        box-shadow: 0 -3px 10px rgba(0, 0, 0, 0.05);
        width: 100%;
        z-index: 100;
        position: bottom;
    }

    .site-footer .footer-inner {
        padding: 15px 20px;
    }

    .site-footer .text-center {
        font-weight: 500;
        color: #555;
        font-size: 16px;
    }

    /* For right-panel layout structure often used in admin panels */
    #right-panel {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    /* If you have a fixed header, add this to prevent content overlap */
    @media screen and (max-width: 767px) {
        .site-footer {
            margin-bottom: 0;
        }
    }
</style>

<footer class="site-footer">
    <div class="footer-inner bg-white">
        <div class="row">
            <div class="col-sm-6 text-center">
                Vehicle Parking Management System
            </div>
        </div>
    </div>
</footer>