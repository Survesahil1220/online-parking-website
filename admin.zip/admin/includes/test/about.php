<?php
// Add PHP logic here if needed (e.g., fetching team data from a database)
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="keywords" content="PrimeCare, About, Baby Care" />
  <meta name="description" content="Learn more about PrimeCare, our mission, and how we care for your little ones." />
  <meta name="author" content="PrimeCare Team" />

  <title>PrimeCare - About</title>

  <!-- External Stylesheets -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet" />

  <!-- Inline CSS -->
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Poppins', sans-serif;
      background: #f9f9f9;
      color: #333;
      line-height: 1.6;
      overflow-x: hidden;
    }

    /* Header */
    header {
      background: #fff;
      padding: 15px 0;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 20px;
    }
    .navbar-brand {
      font-size: 1.8rem;
      font-weight: 700;
      color: #ff6b6b;
      text-transform: uppercase;
      text-decoration: none;
    }
    .nav-links {
      display: flex;
      gap: 20px;
    }
    .nav-links a {
      color: #2c3e50;
      text-decoration: none;
      font-weight: 500;
      transition: color 0.3s ease;
    }
    .nav-links a:hover, .nav-links a.active {
      color: #ff6b6b;
    }
    .nav-toggle {
      display: none;
      font-size: 1.5rem;
      background: none;
      border: none;
      color: #2c3e50;
      cursor: pointer;
    }

    /* About Hero Section */
    .about-hero {
      background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%);
      padding: 80px 20px;
      text-align: center;
    }
    .about-hero h1 {
      font-size: 2.8rem;
      font-weight: 700;
      color: #2c3e50;
      margin-bottom: 20px;
    }
    .about-hero p {
      font-size: 1.1rem;
      color: #666;
      max-width: 700px;
      margin: 0 auto;
    }

    /* About Section */
    .about-section {
      padding: 80px 20px;
      background: #fff;
    }
    .section-title {
      font-size: 2.5rem;
      font-weight: 700;
      color: #2c3e50;
      text-align: center;
      margin-bottom: 40px;
      position: relative;
    }
    .section-title::after {
      content: '';
      width: 50px;
      height: 4px;
      background: #ff6b6b;
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
    }
    .about-content {
      max-width: 1000px;
      margin: 0 auto;
      text-align: center;
    }
    .about-content p {
      font-size: 1rem;
      color: #666;
      margin: 20px 0;
    }
    .about-image {
      max-width: 600px;
      margin: 40px auto;
    }
    .about-image img {
      max-width: 100%;
      border-radius: 15px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }
    .mission {
      background: #f9f9f9;
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
      margin-top: 40px;
    }
    .mission h3 {
      font-size: 1.8rem;
      color: #ff6b6b;
      margin-bottom: 15px;
    }

    /* Footer */
    footer {
      background: #2c3e50;
      color: #fff;
      padding: 40px 20px;
      text-align: center;
    }
    .footer-content {
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap;
      max-width: 1200px;
      margin: 0 auto 20px;
    }
    .footer-content div {
      margin: 20px;
    }
    .footer-content h5 {
      font-size: 1.2rem;
      margin-bottom: 15px;
    }
    .footer-content a {
      color: #fff;
      text-decoration: none;
      display: block;
      margin: 10px 0;
      transition: color 0.3s ease;
    }
    .footer-content a:hover {
      color: #ff6b6b;
    }
    .footer-content .social a {
      font-size: 1.5rem;
      margin: 0 10px;
    }
    footer p a {
      color: #ff6b6b;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .nav-links {
        display: none;
        flex-direction: column;
        position: absolute;
        top: 60px;
        right: 0;
        background: #fff;
        width: 200px;
        padding: 20px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      }
      .nav-links.active {
        display: flex;
      }
      .nav-toggle {
        display: block;
      }
      .about-hero h1 {
        font-size: 2rem;
      }
      .mission {
        padding: 20px;
      }
      .footer-content {
        flex-direction: column;
      }
    }
  </style>
</head>

<body>
  <!-- Header -->
  <header>
    <div class="container">
      <nav class="navbar">
        <a href="index.php" class="navbar-brand">PrimeCare</a>
        <div class="nav-links">
          <a href="index.php">Home</a>
          <a href="about.php" class="active">About</a>
          <a href="services.php">Services</a>
          <a href="contact.php">Contact</a>
        </div>
        <button class="nav-toggle"><i class="fas fa-bars"></i></button>
      </nav>
    </div>
  </header>

  <!-- About Hero Section -->
  <section class="about-hero">
    <h1>About PrimeCare</h1>
    <p>Discover who we are and why we’re passionate about caring for your little ones.</p>
  </section>

  <!-- About Section -->
  <section class="about-section">
    <h2 class="section-title">Our Story</h2>
    <div class="about-content">
      <p>PrimeCare was founded with a simple mission: to provide exceptional care and support for babies and their families. Our team of dedicated professionals brings years of experience and a deep commitment to ensuring every child thrives in a safe, loving environment.</p>
      <p>We understand the challenges parents face, and we’re here to ease that burden with reliable, high-quality baby care services tailored to your needs.</p>
      <div class="about-image">
        <img src="https://via.placeholder.com/600x400?text=Our+Team" alt="PrimeCare Team" />
      </div>
      <div class="mission">
        <h3>Our Mission</h3>
        <p>To create a nurturing space where babies grow, learn, and feel loved, while giving parents peace of mind and confidence in our care.</p>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer>
    <div class="footer-content">
      <div>
        <h5>Contact Info</h5>
        <a href=""><i class="fas fa-map-marker-alt"></i> Wisigaton Lpusm Loram</a>
        <a href=""><i class="fas fa-phone"></i> +01 123455678990</a>
        <a href=""><i class="fas fa-envelope"></i> demo@gmail.com</a>
      </div>
      <div>
        <h5>Quick Links</h5>
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="services.php">Services</a>
        <a href="contact.php">Contact</a>
      </div>
      <div class="social">
        <h5>Follow Us</h5>
        <a href=""><i class="fab fa-facebook-f"></i></a>
        <a href=""><i class="fab fa-twitter"></i></a>
        <a href=""><i class="fab fa-instagram"></i></a>
      </div>
    </div>
    <p>© <span id="displayYear"></span> PrimeCare. All Rights Reserved.</p>
  </footer>

  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    $(document).ready(function() {
      $("#displayYear").text(new Date().getFullYear());
      $('.nav-toggle').click(function() {
        $('.nav-links').toggleClass('active');
      });
    });
  </script>
</body>
</html>