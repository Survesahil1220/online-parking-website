<?php
// Add PHP logic here if needed (e.g., fetching services from a database)
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="keywords" content="PrimeCare, Baby Care, Babysitting, Services" />
  <meta name="description" content="Explore the range of baby care services offered by PrimeCare, designed to ensure your child's well-being." />
  <meta name="author" content="PrimeCare Team" />

  <title>PrimeCare - Services</title>

  <!-- External Stylesheets -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet" />

  <!-- Inline CSS -->
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Poppins', sans-serif;
      background: #f9f9f9;
      color: #333;
      line-height: 1.6;
      overflow-x: hidden;
    }

    /* Header */
    header {
      background: #fff;
      padding: 15px 0;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 20px;
    }
    .navbar-brand {
      font-size: 1.8rem;
      font-weight: 700;
      color: #ff6b6b;
      text-transform: uppercase;
      text-decoration: none;
    }
    .nav-links {
      display: flex;
      gap: 20px;
    }
    .nav-links a {
      color: #2c3e50;
      text-decoration: none;
      font-weight: 500;
      transition: color 0.3s ease;
    }
    .nav-links a:hover, .nav-links a.active {
      color: #ff6b6b;
    }
    .nav-toggle {
      display: none;
      font-size: 1.5rem;
      background: none;
      border: none;
      color: #2c3e50;
      cursor: pointer;
    }

    /* Services Hero Section */
    .services-hero {
      background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%);
      padding: 80px 20px;
      text-align: center;
    }
    .services-hero h1 {
      font-size: 2.8rem;
      font-weight: 700;
      color: #2c3e50;
      margin-bottom: 20px;
    }
    .services-hero p {
      font-size: 1.1rem;
      color: #666;
      max-width: 700px;
      margin: 0 auto;
    }

    /* Services Section */
    .services-section {
      padding: 80px 20px;
      background: #fff;
    }
    .section-title {
      font-size: 2.5rem;
      font-weight: 700;
      color: #2c3e50;
      text-align: center;
      margin-bottom: 40px;
      position: relative;
    }
    .section-title::after {
      content: '';
      width: 50px;
      height: 4px;
      background: #ff6b6b;
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
    }
    .service-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1000px;
      margin: 40px auto;
      background: #f9f9f9;
      border-radius: 15px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
      padding: 20px;
      transition: transform 0.3s ease;
    }
    .service-item:hover {
      transform: translateY(-10px);
    }
    .service-item img {
      max-width: 200px;
      border-radius: 10px;
    }
    .service-content {
      flex: 1;
      padding: 20px;
    }
    .service-content h3 {
      font-size: 1.8rem;
      font-weight: 600;
      color: #ff6b6b;
      margin-bottom: 15px;
    }
    .service-content p {
      font-size: 1rem;
      color: #666;
      margin-bottom: 20px;
    }
    .service-content .btn {
      background: #ff6b6b;
      color: #fff;
      padding: 10px 25px;
      border-radius: 25px;
      text-decoration: none;
      font-weight: 500;
      transition: background 0.3s ease;
    }
    .service-content .btn:hover {
      background: #e65b5b;
    }
    .service-item:nth-child(even) {
      flex-direction: row-reverse;
    }

    /* Footer */
    footer {
      background: #2c3e50;
      color: #fff;
      padding: 40px 20px;
      text-align: center;
    }
    .footer-content {
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap;
      max-width: 1200px;
      margin: 0 auto 20px;
    }
    .footer-content div {
      margin: 20px;
    }
    .footer-content h5 {
      font-size: 1.2rem;
      margin-bottom: 15px;
    }
    .footer-content a {
      color: #fff;
      text-decoration: none;
      display: block;
      margin: 10px 0;
      transition: color 0.3s ease;
    }
    .footer-content a:hover {
      color: #ff6b6b;
    }
    .footer-content .social a {
      font-size: 1.5rem;
      margin: 0 10px;
    }
    footer p a {
      color: #ff6b6b;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .nav-links {
        display: none;
        flex-direction: column;
        position: absolute;
        top: 60px;
        right: 0;
        background: #fff;
        width: 200px;
        padding: 20px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      }
      .nav-links.active {
        display: flex;
      }
      .nav-toggle {
        display: block;
      }
      .services-hero h1 {
        font-size: 2rem;
      }
      .service-item {
        flex-direction: column;
        text-align: center;
      }
      .service-item:nth-child(even) {
        flex-direction: column;
      }
      .service-item img {
        max-width: 150px;
        margin-bottom: 20px;
      }
      .footer-content {
        flex-direction: column;
      }
    }
  </style>
</head>

<body>
  <!-- Header -->
  <header>
    <div class="container">
      <nav class="navbar">
        <a href="index.php" class="navbar-brand">PrimeCare</a>
        <div class="nav-links">
          <a href="index.php">Home</a>
          <a href="about.php">About</a>
          <a href="services.php" class="active">Services</a>
          <a href="contact.php">Contact</a>
        </div>
        <button class="nav-toggle"><i class="fas fa-bars"></i></button>
      </nav>
    </div>
  </header>

  <!-- Services Hero Section -->
  <section class="services-hero">
    <h1>Our Services</h1>
    <p>Discover how PrimeCare ensures your baby’s happiness, health, and development with our expert care services.</p>
  </section>

  <!-- Services Section -->
  <section class="services-section">
    <h2 class="section-title">What We Offer</h2>
    <div class="service-item">
      <img src="https://via.placeholder.com/200?text=Baby+Milk" alt="Baby Milk" />
      <div class="service-content">
        <h3>Baby Milk</h3>
        <p>We provide high-quality, nutritionally balanced baby milk to support your child’s growth and development. Our formulas are carefully selected to meet the needs of every baby.</p>
        <a href="#" class="btn">Learn More</a>
      </div>
    </div>
    <div class="service-item">
      <img src="https://via.placeholder.com/200?text=Baby+Clothes" alt="Baby Clothes" />
      <div class="service-content">
        <h3>Baby Clothes</h3>
        <p>Our range of soft, comfortable, and stylish baby clothes ensures your little one stays cozy and cute. Made from safe, hypoallergenic materials.</p>
        <a href="#" class="btn">Learn More</a>
      </div>
    </div>
    <div class="service-item">
      <img src="https://via.placeholder.com/200?text=Baby+Care" alt="Baby Care" />
      <div class="service-content">
        <h3>Baby Care</h3>
        <p>Comprehensive care tailored to your baby’s unique needs, including feeding, bathing, and daily activities, all delivered with love and expertise.</p>
        <a href="#" class="btn">Learn More</a>
      </div>
    </div>
    <div class="service-item">
      <img src="https://via.placeholder.com/200?text=Babysitting" alt="Babysitting" />
      <div class="service-content">
        <h3>Babysitting</h3>
        <p>Our certified babysitters offer reliable, safe, and nurturing care, giving you peace of mind while you’re away. Available for short-term or regular schedules.</p>
        <a href="#" class="btn">Learn More</a>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer>
    <div class="footer-content">
      <div>
        <h5>Contact Info</h5>
        <a href=""><i class="fas fa-map-marker-alt"></i> Wisigaton Lpusm Loram</a>
        <a href=""><i class="fas fa-phone"></i> +01 123455678990</a>
        <a href=""><i class="fas fa-envelope"></i> demo@gmail.com</a>
      </div>
      <div>
        <h5>Quick Links</h5>
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="services.php">Services</a>
        <a href="contact.php">Contact</a>
      </div>
      <div class="social">
        <h5>Follow Us</h5>
        <a href=""><i class="fab fa-facebook-f"></i></a>
        <a href=""><i class="fab fa-twitter"></i></a>
        <a href=""><i class="fab fa-instagram"></i></a>
      </div>
    </div>
    <p>© <span id="displayYear"></span> PrimeCare. All Rights Reserved.</p>
  </footer>

  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    $(document).ready(function() {
      $("#displayYear").text(new Date().getFullYear());
      $('.nav-toggle').click(function() {
        $('.nav-links').toggleClass('active');
      });
    });
  </script>
</body>
</php>