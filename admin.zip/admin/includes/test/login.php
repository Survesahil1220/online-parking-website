<?php
session_start();
error_reporting(0);

$host = 'localhost';
$dbname = 'primecare_db';
$username = 'root'; // Default XAMPP username
$password = '';     // Default XAMPP password (empty)

$con = mysqli_connect($host, $username, $password, $dbname);
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


if (isset($_POST['login'])) {
    $adminuser = $_POST['username'];
    $password = md5($_POST['password']);
    $query = mysqli_query($con, "SELECT ID FROM users WHERE UserName='$adminuser' AND Password='$password'");
    $ret = mysqli_fetch_array($query);
    if ($ret > 0) {
        $_SESSION['vpmsaid'] = $ret['ID'];
        header('location:dashboard.php');
    } else {
        echo "<script>alert('Invalid Details.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="keywords" content="PrimeCare, Login, Baby Care" />
  <meta name="description" content="Login to your PrimeCare account to manage your baby care services." />
  <meta name="author" content="PrimeCare Team" />

  <title>PrimeCare - Login</title>

  <!-- External Stylesheets -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet" />

  <!-- Inline CSS -->
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Poppins', sans-serif;
      background: #f9f9f9;
      color: #333;
      line-height: 1.6;
      overflow-x: hidden;
    }

    /* Header */
    header {
      background: #fff;
      padding: 15px 0;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 20px;
    }
    .navbar-brand {
      font-size: 1.8rem;
      font-weight: 700;
      color: #ff6b6b;
      text-transform: uppercase;
      text-decoration: none;
    }
    .nav-links {
      display: flex;
      gap: 20px;
    }
    .nav-links a {
      color: #2c3e50;
      text-decoration: none;
      font-weight: 500;
      transition: color 0.3s ease;
    }
    .nav-links a:hover, .nav-links a.active {
      color: #ff6b6b;
    }
    .nav-toggle {
      display: none;
      font-size: 1.5rem;
      background: none;
      border: none;
      color: #2c3e50;
      cursor: pointer;
    }

    /* Login Section */
    .login-container {
      max-width: 400px;
      margin: 100px auto;
      padding: 30px;
      background: #fff;
      border-radius: 15px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
      text-align: center;
    }
    .login-container h2 {
      font-size: 2rem;
      color: #ff6b6b;
      margin-bottom: 20px;
    }
    .form-group {
      margin-bottom: 20px;
    }
    .form-group input {
      width: 100%;
      padding: 12px;
      border: 1px solid #ddd;
      border-radius: 25px;
      font-size: 1rem;
    }
    .btn {
      background: #ff6b6b;
      color: #fff;
      padding: 12px 30px;
      border: none;
      border-radius: 25px;
      font-size: 1rem;
      width: 100%;
      transition: background 0.3s ease;
    }
    .btn:hover {
      background: #e65b5b;
    }
    .forgot-password {
      margin-top: 15px;
    }
    .forgot-password a {
      color: #ff6b6b;
      text-decoration: none;
      font-size: 0.9rem;
    }
    .forgot-password a:hover {
      text-decoration: underline;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .nav-links {
        display: none;
        flex-direction: column;
        position: absolute;
        top: 60px;
        right: 0;
        background: #fff;
        width: 200px;
        padding: 20px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      }
      .nav-links.active {
        display: flex;
      }
      .nav-toggle {
        display: block;
      }
      .login-container {
        margin: 50px auto;
        width: 90%;
      }
    }
  </style>
</head>
<body>
  <!-- Header -->
  <header>
    <div class="container">
      <nav class="navbar">
        <a href="index.php" class="navbar-brand">PrimeCare</a>
        <div class="nav-links">
          <a href="index.php">Home</a>
          <a href="about.php">About</a>
          <a href="services.php">Services</a>
          <a href="contact.php">Contact</a>
          <a href="login.php" class="active">Login</a>
        </div>
        <button class="nav-toggle"><i class="fas fa-bars"></i></button>
      </nav>
    </div>
  </header>

  <!-- Login Form -->
  <div class="login-container">
    <h2>Login</h2>
    <form method="POST" action="">
      <div class="form-group">
        <input type="text" name="username" placeholder="Username" required />
      </div>
      <div class="form-group">
        <input type="password" name="password" placeholder="Password" required />
      </div>
      <a href="dashbord.php" name="login" class="btn">Sign In</a>
      <div class="forgot-password">
        <a href="forgot-password.php">Forgotten Password?</a>
      </div>
    </form>
  </div>

  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    $(document).ready(function() {
      $('.nav-toggle').click(function() {
        $('.nav-links').toggleClass('active');
      });
    });
  </script>
</body>
</html>