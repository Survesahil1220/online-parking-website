<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['vpmsaid'])) {
    
}

// Database connection
$host = 'localhost';
$dbname = 'primecare_db';
$username = 'root';
$password = '';

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch dashboard data
$total_users = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
$recent_bookings = $conn->query("SELECT b.id, b.service_name, b.booking_date, b.status, u.username 
                                 FROM bookings b 
                                 JOIN users u ON b.user_id = u.id 
                                 ORDER BY b.created_at DESC 
                                 LIMIT 5");
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>PrimeCare - Dashboard</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet" />
  <style>
    body { font-family: 'Poppins', sans-serif; background: #f9f9f9; }
    header { background: #fff; padding: 15px 0; box-shadow: 0 2px 10px rgba(0,0,0,0.1); position: sticky; top: 0; z-index: 1000; }
    .navbar { display: flex; justify-content: space-between; align-items: center; padding: 0 20px; }
    .navbar-brand { font-size: 1.8rem; font-weight: 700; color: #ff6b6b; text-transform: uppercase; text-decoration: none; }
    .nav-links { display: flex; gap: 20px; }
    .nav-links a { color: #2c3e50; text-decoration: none; font-weight: 500; }
    .nav-links a:hover, .nav-links a.active { color: #ff6b6b; }
    .nav-toggle { display: none; font-size: 1.5rem; background: none; border: none; color: #2c3e50; cursor: pointer; }
    .dashboard { padding: 80px 20px; max-width: 1200px; margin: 0 auto; }
    .dashboard h1 { font-size: 2.5rem; color: #2c3e50; text-align: center; margin-bottom: 40px; }
    .stats { display: flex; gap: 20px; flex-wrap: wrap; justify-content: center; }
    .stat-card { background: #fff; padding: 20px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); width: 200px; text-align: center; }
    .stat-card h3 { font-size: 1.5rem; color: #ff6b6b; }
    .stat-card p { font-size: 1rem; color: #666; }
    .bookings-table { margin-top: 40px; }
    .bookings-table table { width: 100%; background: #fff; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
    .bookings-table th, .bookings-table td { padding: 15px; text-align: left; }
    .bookings-table th { background: #ff6b6b; color: #fff; }
    .bookings-table tr:nth-child(even) { background: #f9f9f9; }
    @media (max-width: 768px) {
      .nav-links { display: none; flex-direction: column; position: absolute; top: 60px; right: 0; background: #fff; width: 200px; padding: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
      .nav-links.active { display: flex; }
      .nav-toggle { display: block; }
      .stats { flex-direction: column; align-items: center; }
    }
  </style>
</head>
<body>
  <header>
    <div class="container">
      <nav class="navbar">
        <a href="index.php" class="navbar-brand">PrimeCare</a>
        <div class="nav-links">
          <a href="index.php">Home</a>
          <a href="about.php">About</a>
          <a href="services.php">Services</a>
          <a href="contact.php">Contact</a>
          <a href="login.php" class="active">Login</a>
        </div>
        <button class="nav-toggle"><i class="fas fa-bars"></i></button>
      </nav>
    </div>
  </header>

  <section class="dashboard">
    
    <div class="stats">
      <div class="stat-card">
        <h3><?php echo $total_users; ?></h3>
        <p>Total Users</p>
      </div>
      <div class="stat-card">
        <h3><?php echo $recent_bookings->num_rows; ?></h3>
        <p>Recent Bookings</p>
      </div>
    </div>
    <div class="bookings-table">
      <h2>Recent Bookings</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Service</th>
            <th>Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($booking = $recent_bookings->fetch_assoc()) { ?>
            <tr>
              <td><?php echo $booking['id']; ?></td>
              <td><?php echo htmlspecialchars($booking['username']); ?></td>
              <td><?php echo htmlspecialchars($booking['service_name']); ?></td>
              <td><?php echo $booking['booking_date']; ?></td>
              <td><?php echo $booking['status']; ?></td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </section>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    $(document).ready(function() {
      $('.nav-toggle').click(function() {
        $('.nav-links').toggleClass('active');
      });
    });
  </script>
</body>
</html>