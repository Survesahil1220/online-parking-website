<?php
// Add PHP logic here if needed (e.g., form submission handling)
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="keywords" content="PrimeCare, Contact, Baby Care" />
  <meta name="description" content="Get in touch with PrimeCare for any inquiries or to schedule our baby care services." />
  <meta name="author" content="PrimeCare Team" />

  <title>PrimeCare - Contact</title>

  <!-- External Stylesheets -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet" />

  <!-- Inline CSS -->
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Poppins', sans-serif;
      background: #f9f9f9;
      color: #333;
      line-height: 1.6;
      overflow-x: hidden;
    }

    /* Header */
    header {
      background: #fff;
      padding: 15px 0;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 20px;
    }
    .navbar-brand {
      font-size: 1.8rem;
      font-weight: 700;
      color: #ff6b6b;
      text-transform: uppercase;
      text-decoration: none;
    }
    .nav-links {
      display: flex;
      gap: 20px;
    }
    .nav-links a {
      color: #2c3e50;
      text-decoration: none;
      font-weight: 500;
      transition: color 0.3s ease;
    }
    .nav-links a:hover, .nav-links a.active {
      color: #ff6b6b;
    }
    .nav-toggle {
      display: none;
      font-size: 1.5rem;
      background: none;
      border: none;
      color: #2c3e50;
      cursor: pointer;
    }

    /* Contact Hero Section */
    .contact-hero {
      background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%);
      padding: 80px 20px;
      text-align: center;
    }
    .contact-hero h1 {
      font-size: 2.8rem;
      font-weight: 700;
      color: #2c3e50;
      margin-bottom: 20px;
    }
    .contact-hero p {
      font-size: 1.1rem;
      color: #666;
      max-width: 700px;
      margin: 0 auto;
    }

    /* Contact Section */
    .contact-section {
      padding: 80px 20px;
      background: #fff;
      text-align: center;
    }
    .section-title {
      font-size: 2.5rem;
      font-weight: 700;
      color: #2c3e50;
      margin-bottom: 40px;
      position: relative;
    }
    .section-title::after {
      content: '';
      width: 50px;
      height: 4px;
      background: #ff6b6b;
      position: absolute;
      bottom: -10px;
      left: 50%;
      transform: translateX(-50%);
    }
    .contact-form {
      max-width: 600px;
      margin: 0 auto;
      background: #f9f9f9;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }
    .contact-form input, .contact-form textarea {
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      border: 1px solid #ddd;
      border-radius: 25px;
      font-size: 1rem;
    }
    .contact-form textarea {
      height: 150px;
      resize: none;
    }
    .contact-form button {
      background: #ff6b6b;
      border: none;
      padding: 12px 30px;
      color: #fff;
      border-radius: 25px;
      font-size: 1rem;
      transition: background 0.3s ease;
    }
    .contact-form button:hover {
      background: #e65b5b;
    }
    .contact-info {
      max-width: 600px;
      margin: 40px auto 0;
      text-align: left;
    }
    .contact-info h3 {
      font-size: 1.8rem;
      color: #ff6b6b;
      margin-bottom: 20px;
    }
    .contact-info p {
      font-size: 1rem;
      color: #666;
      margin: 10px 0;
    }
    .contact-info i {
      color: #ff6b6b;
      margin-right: 10px;
    }

    /* Footer */
    footer {
      background: #2c3e50;
      color: #fff;
      padding: 40px 20px;
      text-align: center;
    }
    .footer-content {
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap;
      max-width: 1200px;
      margin: 0 auto 20px;
    }
    .footer-content div {
      margin: 20px;
    }
    .footer-content h5 {
      font-size: 1.2rem;
      margin-bottom: 15px;
    }
    .footer-content a {
      color: #fff;
      text-decoration: none;
      display: block;
      margin: 10px 0;
      transition: color 0.3s ease;
    }
    .footer-content a:hover {
      color: #ff6b6b;
    }
    .footer-content .social a {
      font-size: 1.5rem;
      margin: 0 10px;
    }
    footer p a {
      color: #ff6b6b;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .nav-links {
        display: none;
        flex-direction: column;
        position: absolute;
        top: 60px;
        right: 0;
        background: #fff;
        width: 200px;
        padding: 20px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      }
      .nav-links.active {
        display: flex;
      }
      .nav-toggle {
        display: block;
      }
      .contact-hero h1 {
        font-size: 2rem;
      }
      .contact-info {
        text-align: center;
      }
      .footer-content {
        flex-direction: column;
      }
    }
  </style>
</head>

<body>
  <!-- Header -->
  <header>
    <div class="container">
      <nav class="navbar">
        <a href="index.php" class="navbar-brand">PrimeCare</a>
        <div class="nav-links">
          <a href="index.php">Home</a>
          <a href="about.php">About</a>
          <a href="services.php">Services</a>
          <a href="contact.php" class="active">Contact</a>
        </div>
        <button class="nav-toggle"><i class="fas fa-bars"></i></button>
      </nav>
    </div>
  </header>

  <!-- Contact Hero Section -->
  <section class="contact-hero">
    <h1>Contact Us</h1>
    <p>We’re here to assist you with any questions or to help you get started with our baby care services.</p>
  </section>

  <!-- Contact Section -->
  <section class="contact-section">
    <h2 class="section-title">Get In Touch</h2>
    <div class="contact-form">
      <form action="" method="POST">
        <input type="text" name="name" placeholder="Your Name" required />
        <input type="email" name="email" placeholder="Your Email" required />
        <input type="tel" name="phone" placeholder="Your Phone" required />
        <textarea name="message" placeholder="Your Message" required></textarea>
        <button type="submit">Send Message</button>
      </form>
    </div>
    <div class="contact-info">
      <h3>Contact Information</h3>
      <p><i class="fas fa-map-marker-alt"></i> Wisigaton Lpusm Loram</p>
      <p><i class="fas fa-phone"></i> +01 123455678990</p>
      <p><i class="fas fa-envelope"></i> demo@gmail.com</p>
    </div>
  </section>

  <!-- Footer -->
  <footer>
    <div class="footer-content">
      <div>
        <h5>Contact Info</h5>
        <a href=""><i class="fas fa-map-marker-alt"></i> Wisigaton Lpusm Loram</a>
        <a href=""><i class="fas fa-phone"></i> +01 123455678990</a>
        <a href=""><i class="fas fa-envelope"></i> demo@gmail.com</a>
      </div>
      <div>
        <h5>Quick Links</h5>
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="services.php">Services</a>
        <a href="contact.php">Contact</a>
      </div>
      <div class="social">
        <h5>Follow Us</h5>
        <a href=""><i class="fab fa-facebook-f"></i></a>
        <a href=""><i class="fab fa-twitter"></i></a>
        <a href=""><i class="fab fa-instagram"></i></a>
      </div>
    </div>
    <p>© <span id="displayYear"></span> PrimeCare. All Rights Reserved.</p>
  </footer>

  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    $(document).ready(function() {
      $("#displayYear").text(new Date().getFullYear());
      $('.nav-toggle').click(function() {
        $('.nav-links').toggleClass('active');
      });
    });
  </script>
</body>
</html>