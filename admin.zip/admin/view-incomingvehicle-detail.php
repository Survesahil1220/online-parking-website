<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['vpmsaid'] == 0)) {
    header('location:logout.php');
} else {
    if (isset($_POST['submit'])) {
        $cid = $_GET['viewid'];
        $remark = $_POST['remark'];
        $status = $_POST['status'];
        $parkingcharge = $_POST['parkingcharge'];

        // Update OutTime to current time when status changes to 'Out'
        date_default_timezone_set('Asia/Kolkata'); // Set your desired timezone
        $outTime = ($status == 'Out') ? date('Y-m-d H:i:s') : null;

        $query = mysqli_query($con, "UPDATE tblvehicle SET Remark='$remark', Status='$status', ParkingCharge='$parkingcharge', OutTime='$outTime' WHERE ID='$cid'");
        if ($query) {
            echo "<script>alert('Vehicle details have been updated');</script>";
            echo "<script>window.location.href='manage-incomingvehicle.php'</script>";
        } else {
            echo "<script>alert('Something Went Wrong. Please try again');</script>";
        }
    }
?>
<!doctype html>
<html class="no-js" lang="">
<head>
    <title>VPMS - View Vehicle Detail</title>
    <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="shortcut icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <script>
        function calculateParkingCharge(inTime) {
            const ratePerHour = 50; // Example: ₹50 per hour, adjust as needed
            const inDate = new Date(inTime);
            const now = new Date();
            const diffMs = now - inDate; // Difference in milliseconds
            const diffHours = Math.max(diffMs / (1000 * 60 * 60), 1); // Convert to hours, minimum 1 hour
            const charge = (diffHours * ratePerHour).toFixed(2);
            document.getElementById('parkingcharge').value = charge;
            document.getElementById('chargeDisplay').textContent = `₹${charge}`;
        }

        function toggleChargeMode() {
            const mode = document.querySelector('input[name="chargeMode"]:checked').value;
            const autoDiv = document.getElementById('autoChargeDiv');
            const manualDiv = document.getElementById('manualChargeDiv');
            const parkingChargeInput = document.getElementById('parkingcharge');
            const manualParkingChargeInput = document.getElementById('manualParkingCharge');

            if (mode === 'auto') {
                autoDiv.classList.remove('hidden');
                manualDiv.classList.add('hidden');
                calculateParkingCharge(document.getElementById('inTimeHidden').value);
                parkingChargeInput.disabled = false; // Enable the hidden input
                manualParkingChargeInput.disabled = true; // Disable the manual input
            } else {
                autoDiv.classList.add('hidden');
                manualDiv.classList.remove('hidden');
                parkingChargeInput.disabled = true; // Disable the hidden input
                manualParkingChargeInput.disabled = false; // Enable the manual input
            }
        }
    </script>
</head>
<body>
    <!-- Left Panel -->
    <?php include_once('includes/sidebar.php'); ?>
    <!-- Right Panel -->
    <?php include_once('includes/header.php'); ?>

    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Dashboard</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="dashboard.php">Dashboard</a></li>
                                <li><a href="manage-incomingvehicle.php">View Vehicle</a></li>
                                <li class="active">Incoming Vehicle</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">View Incoming Vehicle</strong>
                        </div>
                        <div class="card-body">
                            <?php
                            $cid = $_GET['viewid'];
                            $ret = mysqli_query($con, "SELECT * FROM tblvehicle WHERE ID='$cid'");
                            $cnt = 1;
                            while ($row = mysqli_fetch_array($ret)) {
                            ?>
                            <table border="1" class="table table-bordered mg-b-0">
                               
                            <tr>
                                <th>floor</th>
                                 <td><?php echo $row['Floor']; ?></td>

                             </tr>
                                <tr>
                                    <th>Parking Number</th>
                                    <td><?php echo $row['ParkingNumber']; ?></td>
                                </tr>
                                
                                <tr>
                                    <th>Vehicle Category</th>
                                    <td><?php echo $row['VehicleCategory']; ?></td>
                                </tr>
                                <tr>
                                    <th>Vehicle Company Name</th>
                                    <td><?php echo $row['VehicleCompanyname']; ?></td>
                                </tr>
                                <tr>
                                    <th>Registration Number</th>
                                    <td><?php echo $row['RegistrationNumber']; ?></td>
                                </tr>
                                <tr>
                                    <th>Location</th>
                                    <td><?php echo $row['Location']; ?></td>
                                </tr>
                                <tr>
                                    <th>Owner Name</th>
                                    <td><?php echo $row['OwnerName']; ?></td>
                                </tr>
                                <tr>
                                    <th>Owner Contact Number</th>
                                    <td><?php echo $row['OwnerContactNumber']; ?></td>
                                </tr>
                                <tr>
                                    <th>In Time</th>
                                    <td><?php echo $row['InTime']; ?></td>
                                    <input type="hidden" id="inTimeHidden" value="<?php echo $row['InTime']; ?>">
                                </tr>
                                <tr>
                                    <th>Status</th>
                                    <td>
                                        <?php
                                        if ($row['Status'] == "") {
                                            echo "Vehicle In";
                                        } elseif ($row['Status'] == "Out") {
                                            echo "Vehicle Out";
                                        }
                                        ?>
                                    </td>
                                </tr>
                            </table>

                            <?php if ($row['Status'] == "IN") { ?>
                            <form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
                                <table class="table mb-0">
                                    <tr>
                                        <th>Remark :</th>
                                        <td>
                                            <textarea name="remark" placeholder="" rows="6" cols="14" class="form-control"></textarea>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Parking Charge Mode:</th>
                                        <td>
                                            <div class="mt-2 flex space-x-4">
                                                <label class="flex items-center">
                                                    <input type="radio" name="chargeMode" value="auto" class="mr-2" onchange="toggleChargeMode()" checked>
                                                    <span>Automatic (Based on In Time)</span>
                                                </label>
                                                <label class="flex items-center">
                                                    <input type="radio" name="chargeMode" value="manual" class="mr-2" onchange="toggleChargeMode()">
                                                    <span>Manual</span>
                                                </label>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr id="autoChargeDiv">
                                        <th>Parking Charge (Auto-Calculated):</th>
                                        <td>
                                            <input type="hidden" name="parkingcharge" id="parkingcharge" value="">
                                            <p class="text-gray-900" id="chargeDisplay"></p>
                                            <button type="button" onclick="calculateParkingCharge(document.getElementById('inTimeHidden').value)" class="text-indigo-600 hover:text-indigo-800 text-sm">Recalculate Now</button>
                                        </td>
                                    </tr>
                                    <tr id="manualChargeDiv" class="hidden">
                                        <th>Parking Charge (Manual):</th>
                                        <td>
                                            <input type="text" name="parkingcharge" id="manualParkingCharge" class="form-control" placeholder="Enter parking charge">
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Status :</th>
                                        <td>
                                            <select name="status" class="form-control" required="true">
                                                <option value="Out">Outgoing Vehicle</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" class="text-center">
                                            <button type="submit" class="btn btn-primary btn-sm" name="submit">Update</button>
                                        </td>
                                    </tr>
                                </table>
                            </form>
                            <?php } else { ?>
                            <table border="1" class="table table-bordered mg-b-0">
                                <tr>
                                    <th>Remark</th>
                                    <td><?php echo $row['Remark']; ?></td>
                                </tr>
                                <tr>
                                    <th>Parking Fee</th>
                                    <td><?php echo $row['ParkingCharge']; ?></td>
                                </tr>
                                <tr>
                                    <th>Out Time</th>
                                    <td><?php echo $row['OutTime'] ?? 'N/A'; ?></td>
                                </tr>
                            </table>
                            <?php } ?>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include_once('includes/footer.php'); ?>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="assets/js/main.js"></script>

    <script>
        // Initialize charge mode on page load
        window.onload = function() {
            toggleChargeMode();
        };
    </script>
</body>
</html>
<?php } ?>